package com.example.data.repository

import android.content.Context
import com.example.data.local.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AppRepository(context: Context) {
    private val database = AppDatabase.getDatabase(context)
    private val bookDao = database.bookDao()
    private val readingProgressDao = database.readingProgressDao()
    private val quizDao = database.quizDao()
    private val quizResultDao = database.quizResultDao()
    private val pastPaperDao = database.pastPaperDao()
    private val revisionNoteDao = database.revisionNoteDao()
    private val userDao = database.userDao()

    init {
        CoroutineScope(Dispatchers.IO).launch {
            seedInitialDataIfEmpty()
        }
    }

    private suspend fun seedInitialDataIfEmpty() {
        val count = bookDao.getBookCount().first()
        if (count == 0) {
            bookDao.insertBooks(DefaultData.getInitialBooks())
            quizDao.insertQuizzes(DefaultData.getInitialQuizzes())
            quizDao.insertQuestions(DefaultData.getInitialQuizQuestions())
            pastPaperDao.insertPastPapers(DefaultData.getInitialPastPapers())
            revisionNoteDao.insertNotes(DefaultData.getInitialRevisionNotes())
            userDao.insertUser(DefaultData.getInitialUser())
            
            // Seed a sample reading progress
            readingProgressDao.saveProgress(
                ReadingProgressEntity(
                    bookId = "book_math_f1",
                    bookTitle = "Mathematics Form 1",
                    subject = "Mathematics",
                    formLevel = "Form 1",
                    currentPage = 2,
                    totalPages = 184
                )
            )
        }
    }

    // Book Operations
    val allPublishedBooks: Flow<List<BookEntity>> = bookDao.getPublishedBooks()
    val allAdminBooks: Flow<List<BookEntity>> = bookDao.getAllBooks()
    val downloadedBooks: Flow<List<BookEntity>> = bookDao.getDownloadedBooks()
    val favoriteBooks: Flow<List<BookEntity>> = bookDao.getFavoriteBooks()
    val totalBookCount: Flow<Int> = bookDao.getBookCount()
    val downloadedCount: Flow<Int> = bookDao.getDownloadedCount()

    fun getBookById(id: String): Flow<BookEntity?> = bookDao.getBookById(id)
    fun searchBooks(query: String): Flow<List<BookEntity>> = bookDao.searchBooks(query)

    suspend fun insertBook(book: BookEntity) = bookDao.insertBook(book)
    suspend fun updateBook(book: BookEntity) = bookDao.updateBook(book)
    suspend fun deleteBookById(id: String) = bookDao.deleteBookById(id)
    suspend fun toggleFavorite(bookId: String, currentStatus: Boolean) =
        bookDao.setFavorite(bookId, !currentStatus)
    suspend fun toggleDownload(bookId: String, currentStatus: Boolean) =
        bookDao.setDownloaded(bookId, !currentStatus)
    suspend fun setBookPublished(bookId: String, published: Boolean) =
        bookDao.setPublished(bookId, published)

    // Reading Progress
    val allRecentProgress: Flow<List<ReadingProgressEntity>> = readingProgressDao.getAllProgress()
    fun getProgressForBook(bookId: String): Flow<ReadingProgressEntity?> =
        readingProgressDao.getProgressForBook(bookId)
    suspend fun saveReadingProgress(progress: ReadingProgressEntity) =
        readingProgressDao.saveProgress(progress)

    // Quizzes
    val allQuizzes: Flow<List<QuizEntity>> = quizDao.getAllQuizzes()
    val allAdminQuizzes: Flow<List<QuizEntity>> = quizDao.getAllAdminQuizzes()
    val dailyQuiz: Flow<QuizEntity?> = quizDao.getDailyQuiz()
    fun getQuestionsForQuiz(quizId: String): Flow<List<QuizQuestionEntity>> =
        quizDao.getQuestionsForQuiz(quizId)

    suspend fun insertQuizWithQuestions(quiz: QuizEntity, questions: List<QuizQuestionEntity>) {
        quizDao.insertQuiz(quiz)
        quizDao.insertQuestions(questions)
    }

    suspend fun deleteQuiz(quizId: String) {
        quizDao.deleteQuiz(quizId)
        quizDao.deleteQuestionsForQuiz(quizId)
    }

    // Quiz Results
    val allQuizResults: Flow<List<QuizResultEntity>> = quizResultDao.getAllResults()
    val completedQuizzesCount: Flow<Int> = quizResultDao.getCompletedQuizCount()
    suspend fun recordQuizResult(result: QuizResultEntity) = quizResultDao.insertResult(result)

    // Past Papers
    val allPastPapers: Flow<List<PastPaperEntity>> = pastPaperDao.getAllPastPapers()
    val savedPastPapers: Flow<List<PastPaperEntity>> = pastPaperDao.getSavedPastPapers()
    fun getPastPapersByForm(form: String): Flow<List<PastPaperEntity>> =
        pastPaperDao.getPastPapersByForm(form)
    suspend fun togglePastPaperDownload(id: String, current: Boolean) =
        pastPaperDao.setDownloaded(id, !current)
    suspend fun togglePastPaperSaved(id: String, current: Boolean) =
        pastPaperDao.setSaved(id, !current)
    suspend fun insertPastPaper(paper: PastPaperEntity) = pastPaperDao.insertPastPaper(paper)
    suspend fun deletePastPaper(id: String) = pastPaperDao.deletePastPaper(id)

    // Revision Notes
    val allRevisionNotes: Flow<List<RevisionNoteEntity>> = revisionNoteDao.getAllNotes()
    val savedRevisionNotes: Flow<List<RevisionNoteEntity>> = revisionNoteDao.getSavedNotes()
    suspend fun toggleNoteSaved(id: String, current: Boolean) =
        revisionNoteDao.setSaved(id, !current)
    suspend fun insertRevisionNote(note: RevisionNoteEntity) = revisionNoteDao.insertNote(note)
    suspend fun deleteRevisionNote(id: String) = revisionNoteDao.deleteNote(id)

    // User Account
    val currentUser: Flow<UserAccountEntity?> = userDao.getUser()
    suspend fun updateUser(user: UserAccountEntity) = userDao.updateUser(user)
    suspend fun switchRole(newRole: String) {
        val user = currentUser.first() ?: DefaultData.getInitialUser()
        userDao.updateUser(user.copy(role = newRole))
    }
}
