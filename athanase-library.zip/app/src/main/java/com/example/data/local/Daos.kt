package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {
    @Query("SELECT * FROM books ORDER BY createdAt DESC")
    fun getAllBooks(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE isPublished = 1 ORDER BY createdAt DESC")
    fun getPublishedBooks(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE id = :id")
    fun getBookById(id: String): Flow<BookEntity?>

    @Query("SELECT * FROM books WHERE isDownloaded = 1")
    fun getDownloadedBooks(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE isFavorite = 1")
    fun getFavoriteBooks(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE title LIKE '%' || :query || '%' OR subject LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%'")
    fun searchBooks(query: String): Flow<List<BookEntity>>

    @Query("SELECT COUNT(*) FROM books")
    fun getBookCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM books WHERE isDownloaded = 1")
    fun getDownloadedCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooks(books: List<BookEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBook(book: BookEntity)

    @Update
    suspend fun updateBook(book: BookEntity)

    @Query("UPDATE books SET isFavorite = :isFavorite WHERE id = :bookId")
    suspend fun setFavorite(bookId: String, isFavorite: Boolean)

    @Query("UPDATE books SET isDownloaded = :isDownloaded, downloadProgress = 100 WHERE id = :bookId")
    suspend fun setDownloaded(bookId: String, isDownloaded: Boolean)

    @Query("UPDATE books SET isPublished = :isPublished WHERE id = :bookId")
    suspend fun setPublished(bookId: String, isPublished: Boolean)

    @Delete
    suspend fun deleteBook(book: BookEntity)

    @Query("DELETE FROM books WHERE id = :bookId")
    suspend fun deleteBookById(bookId: String)
}

@Dao
interface ReadingProgressDao {
    @Query("SELECT * FROM reading_progress ORDER BY lastReadTimestamp DESC")
    fun getAllProgress(): Flow<List<ReadingProgressEntity>>

    @Query("SELECT * FROM reading_progress WHERE bookId = :bookId")
    fun getProgressForBook(bookId: String): Flow<ReadingProgressEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProgress(progress: ReadingProgressEntity)

    @Query("DELETE FROM reading_progress WHERE bookId = :bookId")
    suspend fun deleteProgress(bookId: String)
}

@Dao
interface QuizDao {
    @Query("SELECT * FROM quizzes WHERE isPublished = 1 ORDER BY createdAt DESC")
    fun getAllQuizzes(): Flow<List<QuizEntity>>

    @Query("SELECT * FROM quizzes ORDER BY createdAt DESC")
    fun getAllAdminQuizzes(): Flow<List<QuizEntity>>

    @Query("SELECT * FROM quizzes WHERE isDailyChallenge = 1 LIMIT 1")
    fun getDailyQuiz(): Flow<QuizEntity?>

    @Query("SELECT * FROM quiz_questions WHERE quizId = :quizId ORDER BY questionNumber ASC")
    fun getQuestionsForQuiz(quizId: String): Flow<List<QuizQuestionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizzes(quizzes: List<QuizEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuiz(quiz: QuizEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestions(questions: List<QuizQuestionEntity>)

    @Query("DELETE FROM quizzes WHERE id = :quizId")
    suspend fun deleteQuiz(quizId: String)

    @Query("DELETE FROM quiz_questions WHERE quizId = :quizId")
    suspend fun deleteQuestionsForQuiz(quizId: String)
}

@Dao
interface QuizResultDao {
    @Query("SELECT * FROM quiz_results ORDER BY completedAt DESC")
    fun getAllResults(): Flow<List<QuizResultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResult(result: QuizResultEntity)

    @Query("SELECT COUNT(*) FROM quiz_results")
    fun getCompletedQuizCount(): Flow<Int>
}

@Dao
interface PastPaperDao {
    @Query("SELECT * FROM past_papers ORDER BY year DESC, title ASC")
    fun getAllPastPapers(): Flow<List<PastPaperEntity>>

    @Query("SELECT * FROM past_papers WHERE formLevel = :form ORDER BY year DESC")
    fun getPastPapersByForm(form: String): Flow<List<PastPaperEntity>>

    @Query("SELECT * FROM past_papers WHERE isSaved = 1")
    fun getSavedPastPapers(): Flow<List<PastPaperEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPastPapers(papers: List<PastPaperEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPastPaper(paper: PastPaperEntity)

    @Query("UPDATE past_papers SET isDownloaded = :isDownloaded WHERE id = :id")
    suspend fun setDownloaded(id: String, isDownloaded: Boolean)

    @Query("UPDATE past_papers SET isSaved = :isSaved WHERE id = :id")
    suspend fun setSaved(id: String, isSaved: Boolean)

    @Query("DELETE FROM past_papers WHERE id = :id")
    suspend fun deletePastPaper(id: String)
}

@Dao
interface RevisionNoteDao {
    @Query("SELECT * FROM revision_notes ORDER BY formLevel ASC, subject ASC")
    fun getAllNotes(): Flow<List<RevisionNoteEntity>>

    @Query("SELECT * FROM revision_notes WHERE isSaved = 1")
    fun getSavedNotes(): Flow<List<RevisionNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotes(notes: List<RevisionNoteEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: RevisionNoteEntity)

    @Query("UPDATE revision_notes SET isSaved = :isSaved WHERE id = :id")
    suspend fun setSaved(id: String, isSaved: Boolean)

    @Query("DELETE FROM revision_notes WHERE id = :id")
    suspend fun deleteNote(id: String)
}

@Dao
interface UserDao {
    @Query("SELECT * FROM user_account LIMIT 1")
    fun getUser(): Flow<UserAccountEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserAccountEntity)

    @Update
    suspend fun updateUser(user: UserAccountEntity)
}
