package com.example.data.model

enum class FormLevel(val displayNameEn: String, val displayNameSw: String, val shortCode: String) {
    ALL("All Classes", "Madarasa Yote", "ALL"),
    FORM_1("Form 1", "Kidato cha Kwanza", "Form 1"),
    FORM_2("Form 2", "Kidato cha Pili", "Form 2"),
    FORM_3("Form 3", "Kidato cha Tatu", "Form 3"),
    FORM_4("Form 4", "Kidato cha Nne", "Form 4"),
    FORM_5("Form 5", "Kidato cha Tano", "Form 5"),
    FORM_6("Form 6", "Kidato cha Sita", "Form 6");

    fun getTitle(isSwahili: Boolean): String = if (isSwahili) displayNameSw else displayNameEn

    companion object {
        fun fromString(value: String): FormLevel {
            return entries.firstOrNull { 
                it.name.equals(value, ignoreCase = true) || 
                it.displayNameEn.equals(value, ignoreCase = true) ||
                it.shortCode.equals(value, ignoreCase = true)
            } ?: FORM_1
        }
    }
}

enum class Subject(val displayNameEn: String, val displayNameSw: String, val iconName: String) {
    ALL("All Subjects", "Masomo Yote", "apps"),
    MATHEMATICS("Mathematics", "Hisabati", "calculate"),
    PHYSICS("Physics", "Fizikia", "science"),
    CHEMISTRY("Chemistry", "Kemia", "biotech"),
    BIOLOGY("Biology", "Biolojia", "nature"),
    ENGLISH("English Language", "Kiingereza", "translate"),
    KISWAHILI("Kiswahili", "Kiswahili", "menu_book"),
    GEOGRAPHY("Geography", "Jiografia", "public"),
    HISTORY("History", "Historia", "history_edu"),
    CIVICS("Civics", "Uraia", "balance"),
    ICT("ICT / Computer Science", "TEHAMA / Kompyuta", "computer"),
    GENERAL_STUDIES("General Studies", "Stadi za Jumla", "school"),
    BUSINESS_STUDIES("Business Studies", "Biashara", "trending_up"),
    LITERATURE("Literature in English", "Fasihi ya Kiingereza", "auto_stories");

    fun getTitle(isSwahili: Boolean): String = if (isSwahili) displayNameSw else displayNameEn

    companion object {
        fun fromString(value: String): Subject {
            return entries.firstOrNull { 
                it.name.equals(value, ignoreCase = true) || 
                it.displayNameEn.equals(value, ignoreCase = true)
            } ?: MATHEMATICS
        }
    }
}

enum class Difficulty(val labelEn: String, val labelSw: String) {
    EASY("Easy", "Rahisi"),
    MEDIUM("Medium", "Wastani"),
    HARD("Hard", "Ngumu");

    fun getLabel(isSwahili: Boolean): String = if (isSwahili) labelSw else labelEn
}

enum class UserRole {
    STUDENT,
    ADMIN
}

enum class AppLanguage {
    ENGLISH,
    KISWAHILI
}
