package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class BookEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subject: String,
    val formLevel: String,
    val author: String,
    val publisher: String,
    val year: Int,
    val pages: Int,
    val fileSize: String,
    val description: String,
    val rating: Float = 4.8f,
    val isPublished: Boolean = true,
    val isDownloaded: Boolean = false,
    val isFavorite: Boolean = false,
    val downloadProgress: Int = 100,
    val coverColor: Long = 0xFF0F3057,
    val pdfContent: String = "",
    val readCount: Int = 0,
    val downloadCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reading_progress")
data class ReadingProgressEntity(
    @PrimaryKey val bookId: String,
    val bookTitle: String,
    val subject: String,
    val formLevel: String,
    val currentPage: Int,
    val totalPages: Int,
    val lastReadTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "quizzes")
data class QuizEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subject: String,
    val formLevel: String,
    val topic: String,
    val difficulty: String,
    val questionCount: Int,
    val isDailyChallenge: Boolean = false,
    val isPublished: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "quiz_questions")
data class QuizQuestionEntity(
    @PrimaryKey val id: String,
    val quizId: String,
    val questionNumber: Int,
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctAnswerIndex: Int,
    val explanation: String
)

@Entity(tableName = "quiz_results")
data class QuizResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val quizId: String,
    val quizTitle: String,
    val formLevel: String,
    val subject: String,
    val score: Int,
    val totalQuestions: Int,
    val percentage: Int,
    val timeTakenSeconds: Int,
    val completedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "past_papers")
data class PastPaperEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subject: String,
    val formLevel: String,
    val year: Int,
    val examType: String, // CSEE, FTNA, ACSEE, MOCK
    val fileSize: String,
    val isDownloaded: Boolean = false,
    val isSaved: Boolean = false,
    val paperContent: String = ""
)

@Entity(tableName = "revision_notes")
data class RevisionNoteEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subject: String,
    val formLevel: String,
    val topic: String,
    val summary: String,
    val keyFormulas: String,
    val examTips: String,
    val isSaved: Boolean = false
)

@Entity(tableName = "user_account")
data class UserAccountEntity(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val role: String, // STUDENT, ADMIN
    val selectedForm: String,
    val favoriteSubjects: String = "Mathematics, Physics, Chemistry",
    val booksReadCount: Int = 14,
    val booksDownloadedCount: Int = 6,
    val quizzesCompletedCount: Int = 18,
    val averageScore: Int = 85
)
