package com.example.data.repository

import com.example.data.local.*

object DefaultData {
    fun getInitialBooks(): List<BookEntity> = listOf(
        BookEntity(
            id = "book_math_f1",
            title = "Mathematics Form 1",
            subject = "Mathematics",
            formLevel = "Form 1",
            author = "Tanzania Institute of Education (TIE)",
            publisher = "Educational Books Publishers",
            year = 2023,
            pages = 184,
            fileSize = "4.2 MB",
            rating = 4.9f,
            coverColor = 0xFF1E3C72,
            isDownloaded = true,
            isFavorite = true,
            description = "Complete secondary school syllabus for Form One Mathematics according to the Ministry of Education, Science and Technology curriculum. Covers numbers, fractions, decimals, percentages, units, geometry, and basic algebra.",
            pdfContent = """
CHAPTER 1: NUMBERS & INTEGERS
Page 1: Introduction to Natural Numbers and Whole Numbers.
Natural numbers are counting numbers: 1, 2, 3, 4, ...
Whole numbers include zero: 0, 1, 2, 3, ...
Integers include negative whole numbers, zero, and positive whole numbers: ..., -3, -2, -1, 0, 1, 2, 3, ...

Page 2: Operations with Integers
Addition: (+5) + (+3) = +8; (-4) + (-3) = -7.
Subtraction: (+7) - (+2) = 5; (+3) - (-5) = 3 + 5 = 8.
Multiplication: Positive × Positive = Positive; Negative × Negative = Positive; Positive × Negative = Negative.
Order of operations follows BODMAS: Brackets, Orders (Powers/Roots), Division, Multiplication, Addition, Subtraction.

Page 3: Factors, Multiples, and Prime Numbers
A prime number has exactly two factors: 1 and itself (e.g., 2, 3, 5, 7, 11, 13, 17, 19).
Greatest Common Factor (GCF) and Lowest Common Multiple (LCM).
Example: Find GCF of 24 and 36:
Prime factorization: 24 = 2³ × 3; 36 = 2² × 3².
GCF = 2² × 3 = 12.
LCM = 2³ × 3² = 72.

Page 4: Fractions and Decimals
Proper fractions (numerator < denominator), Improper fractions, and Mixed numbers.
Conversion between fractions and recurring decimals.
Scientific notation: A number written as A × 10ⁿ where 1 ≤ A < 10 and n is an integer.
Example: 45,000 = 4.5 × 10⁴.
            """.trimIndent()
        ),
        BookEntity(
            id = "book_phys_f2",
            title = "Physics Form 2",
            subject = "Physics",
            formLevel = "Form 2",
            author = "Dr. J. M. Mwambene",
            publisher = "Dar es Salaam Educational Press",
            year = 2024,
            pages = 210,
            fileSize = "5.8 MB",
            rating = 4.8f,
            coverColor = 0xFF2A5298,
            isDownloaded = true,
            isFavorite = false,
            description = "Covers the standard Form Two Physics syllabus in Tanzania: Magnetism, Forces in Equilibrium, Simple Machines, Motion in Straight Lines, Newton's Laws, and Pressure in Liquids and Gases.",
            pdfContent = """
CHAPTER 1: MAGNETISM
Page 1: Properties of Magnets
A magnet attracts magnetic substances like iron, nickel, and cobalt.
Poles of a magnet: North Pole (N) and South Pole (S).
Law of Magnetism: Like poles repel, unlike poles attract.
Magnetic field lines travel from North to South outside the magnet and form continuous loops.

Page 2: Methods of Magnetization
1. Stroking method (Single stroke and Double stroke).
2. Electrical method: Coiling insulated copper wire around a steel bar and passing direct current (DC).
Methods of Demagnetization: Heating to red hot, hammering violently, alternating current (AC) in a solenoid oriented East-West.

Page 3: Force, Work, Energy and Power
Force (F) = mass (m) × acceleration (a). Unit is Newton (N).
Work done (W) = Force × Distance in the direction of the force. Unit: Joule (J).
Power (P) = Work done / Time taken. Unit: Watt (W).
Mechanical Advantage (M.A) = Load / Effort.
Velocity Ratio (V.R) = Distance moved by effort / Distance moved by load.
Efficiency (η) = (M.A / V.R) × 100%.

Page 4: Pressure in Fluids
Pressure = Force / Area. Unit: Pascal (Pa) or N/m².
Pressure in liquids: P = ρ × g × h (density × acceleration due to gravity × depth).
Pascal's Principle: Pressure applied to an enclosed fluid is transmitted equally in all directions.
Archimedes' Principle: When a body is wholly or partially immersed in a fluid, it experiences an upthrust equal to the weight of fluid displaced.
            """.trimIndent()
        ),
        BookEntity(
            id = "book_chem_f3",
            title = "Chemistry Form 3",
            subject = "Chemistry",
            formLevel = "Form 3",
            author = "Prof. E. K. Msuya & S. A. Bakari",
            publisher = "Tanzania Educational Publishers",
            year = 2023,
            pages = 240,
            fileSize = "6.1 MB",
            rating = 4.9f,
            coverColor = 0xFF7928CA,
            isDownloaded = false,
            isFavorite = true,
            description = "Detailed Form 3 Chemistry course addressing Chemical Equations, Volumetric Analysis (Titration), Ionic Theory, The Periodic Table, Extraction of Metals, and Rates of Chemical Reactions.",
            pdfContent = """
CHAPTER 1: VOLUMETRIC ANALYSIS (TITRATION)
Page 1: Principles of Volumetric Analysis
Volumetric analysis is a quantitative chemical analysis method to determine the concentration of an unknown solution using a standard solution.
Standard solution: A solution of accurately known concentration.
Molarity (M) = Moles of solute / Volume of solution in dm³ (litres).
Moles = Mass (g) / Molar Mass (g/mol).

Page 2: Acid-Base Titration Apparatus and Technique
Key apparatus: Burette, Pipette (25.0 cm³), Conical flask, Retort stand, White tile, Volumetric flask.
Indicators:
- Phenolphthalein: Colorless in acid, Pink in base (Endpoint: pink to colorless for acid into base).
- Methyl orange: Red/Pink in acid, Yellow in base (Endpoint: orange).

Page 3: Titration Calculations
Balanced equation: aA + bB → Products
Formula: (Ma × Va) / (Mb × Vb) = a / b
Where:
Ma = Molarity of acid, Va = Average volume of acid used (titre)
Mb = Molarity of base, Vb = Volume of base pipetted
a = stoichiometric coefficient of acid, b = stoichiometric coefficient of base.

Page 4: Periodic Classification of Elements
Mendeleev's Periodic Table vs Modern Periodic Table (arranged by atomic number).
Group trends:
- Group 1 (Alkali Metals): Reactivity increases down the group.
- Group 7 (Halogens): Reactivity decreases down the group.
- Period 3 trends: Atomic radius decreases across the period from Na to Cl due to increasing effective nuclear charge.
            """.trimIndent()
        ),
        BookEntity(
            id = "book_bio_f4",
            title = "Biology Form 4",
            subject = "Biology",
            formLevel = "Form 4",
            author = "Grace N. Lyimo",
            publisher = "Kilimanjaro Academic Press",
            year = 2024,
            pages = 275,
            fileSize = "7.4 MB",
            rating = 5.0f,
            coverColor = 0xFF007965,
            isDownloaded = false,
            isFavorite = true,
            description = "Essential revision and textbook for Form 4 CSEE preparation: Genetics, Cell Division (Mitosis & Meiosis), Evolution, Ecology, and Human Reproduction.",
            pdfContent = """
CHAPTER 1: GENETICS AND HEREDITY
Page 1: Introduction to Genetics
Genetics is the scientific study of heredity and variation in living organisms.
Heredity: The transmission of traits from parents to offspring.
Key terms:
- Gene: Basic unit of heredity located on chromosomes.
- Alleles: Alternative forms of a gene (e.g., T for tall, t for dwarf).
- Genotype: The genetic constitution of an organism (e.g., TT, Tt, tt).
- Phenotype: The physical expression or visible traits of an organism (e.g., Tall, Short).

Page 2: Mendel's First Law of Inheritance
Mendel's Law of Segregation: Characteristics of an organism are determined by pairs of alleles that separate during gamete formation so that each gamete carries only one allele.
Monohybrid cross: Cross between pure breeding tall plant (TT) and pure breeding dwarf plant (tt).
F1 generation: All Tt (heterozygous tall).
F2 generation ratio: Genotypic ratio = 1 TT : 2 Tt : 1 tt (1:2:1). Phenotypic ratio = 3 Tall : 1 Dwarf (3:1).

Page 3: Sex Determination in Humans
Humans have 23 pairs of chromosomes (46 chromosomes):
- 22 pairs are autosomes.
- 1 pair are sex chromosomes (XX in females, XY in males).
Punnett square shows a 50% chance of male (XY) and 50% chance of female (XX) at each fertilization.
Sex-linked traits: Hemophilia, Red-Green Color Blindness carried on the X chromosome.

Page 4: Ecology and Environmental Conservation
Ecosystem: A biological community of interacting organisms and their physical environment.
Food Chain: Primary Producer → Primary Consumer (Herbivore) → Secondary Consumer (Carnivore) → Decomposer.
Energy flow: Only about 10% of energy is transferred from one trophic level to the next (10% rule).
Conservation in Tanzania: National parks (Serengeti, Ngorongoro, Ruaha), afforestation, anti-poaching measures.
            """.trimIndent()
        ),
        BookEntity(
            id = "book_adv_math_f5",
            title = "Advanced Mathematics Form 5",
            subject = "Mathematics",
            formLevel = "Form 5",
            author = "Eng. P. R. Ndunguru",
            publisher = "Taasisi ya Elimu Tanzania",
            year = 2023,
            pages = 320,
            fileSize = "8.9 MB",
            rating = 4.7f,
            coverColor = 0xFF0D3B66,
            isDownloaded = false,
            isFavorite = false,
            description = "Covers the Advanced Level (ACSEE) Form 5 Mathematics syllabus: Coordinate Geometry, Differential Calculus, Integration, Vectors, Matrices, and Complex Numbers.",
            pdfContent = """
CHAPTER 1: DIFFERENTIAL CALCULUS
Page 1: Limits and First Principles
Definition of derivative:
f'(x) = lim(h → 0) [f(x + h) - f(x)] / h.
Differentiation of xⁿ: d/dx(xⁿ) = n·xⁿ⁻¹.
Product Rule: d/dx(u·v) = u(dv/dx) + v(du/dx).
Quotient Rule: d/dx(u/v) = [v(du/dx) - u(dv/dx)] / v².
Chain Rule: dy/dx = (dy/du) × (du/dx).

Page 2: Applications of Differentiation
Stationary points (critical points) occur where dy/dx = 0.
Second derivative test:
- If d²y/dx² > 0 at x = c, the point is a local minimum.
- If d²y/dx² < 0 at x = c, the point is a local maximum.
- If d²y/dx² = 0, check sign change for inflection point.
Rates of change and optimization problems.

Page 3: Integration Fundamentals
Integration as the reverse process of differentiation:
∫ xⁿ dx = (xⁿ⁺¹) / (n + 1) + C, where n ≠ -1.
Definite integrals and area under curves between x = a and x = b:
Area = ∫[a to b] y dx.
Integration by substitution and integration by parts: ∫ u dv = uv - ∫ v du.
            """.trimIndent()
        ),
        BookEntity(
            id = "book_phys_f6",
            title = "Physics Form 6",
            subject = "Physics",
            formLevel = "Form 6",
            author = "Dr. K. S. Mhando",
            publisher = "Academic Excellence Series",
            year = 2024,
            pages = 345,
            fileSize = "9.5 MB",
            rating = 4.8f,
            coverColor = 0xFF3D085A,
            isDownloaded = false,
            isFavorite = false,
            description = "Form 6 ACSEE syllabus covering Electromagnetism, Alternating Current Circuits, Atomic Physics, Nuclear Physics, Electronics, and Telecommunications.",
            pdfContent = """
CHAPTER 1: ELECTROMAGNETIC INDUCTION
Page 1: Faraday's and Lenz's Laws
Faraday's First Law: Whenever magnetic flux linked with a circuit changes, an electromotive force (EMF) is induced.
Faraday's Second Law: The magnitude of induced EMF is proportional to the rate of change of magnetic flux linkage:
E = - N (dΦ/dt).
Lenz's Law: The direction of induced current opposes the change in magnetic flux producing it (represented by negative sign).

Page 2: Mutual and Self-Inductance
Self-inductance (L): Induced EMF = - L (dI/dt). Unit is Henry (H).
Energy stored in an inductor: E = ½ L I².
Mutual inductance (M) between two coils: E₂ = - M (dI₁/dt).
Transformer equation: Vp / Vs = Np / Ns = Is / Ip (for ideal 100% efficient transformer).

Page 3: Nuclear Physics and Radioactivity
Law of Radioactive Decay: N(t) = N₀ e^(-λt).
Half-life (T½): Time taken for half the radioactive nuclei to disintegrate:
T½ = ln(2) / λ ≈ 0.693 / λ.
Nuclear fission: Splitting of heavy nucleus into lighter nuclei with energy release (e.g., U-235).
Nuclear fusion: Combining light nuclei into heavier nucleus (powers the Sun).
            """.trimIndent()
        ),
        BookEntity(
            id = "book_eng_f2",
            title = "English Language Form 2",
            subject = "English",
            formLevel = "Form 2",
            author = "Sarah J. Kweka",
            publisher = "Oxford University Press East Africa",
            year = 2023,
            pages = 176,
            fileSize = "3.8 MB",
            rating = 4.6f,
            coverColor = 0xFFD97706,
            isDownloaded = false,
            isFavorite = false,
            description = "Comprehensive English language course for Form 2: Grammar, Vocabulary, Reading Comprehension, Summary Writing, Composition, and Literary Analysis.",
            pdfContent = """
UNIT 1: EXPRESSING HABITUAL ACTIONS AND CONDITIONALS
Page 1: Present Simple and Present Continuous Tenses
The present simple tense expresses habits, general truths, and regular routines:
Example: "The sun rises in the east." "Juma studies every evening."
Present continuous expresses actions happening at the moment of speaking:
Example: "The students are preparing for their mid-term examinations."

Page 2: Conditional Sentences (Types 0, 1, and 2)
Zero Conditional: If + Present Simple, Present Simple (Scientific facts).
"If you heat water to 100°C, it boils."
First Conditional: If + Present Simple, will + base verb (Likely future situations).
"If you study diligently, you will pass your NECTA examinations."
Second Conditional: If + Past Simple, would + base verb (Hypothetical/unreal).
"If I had wings, I would fly across Mount Kilimanjaro."
            """.trimIndent()
        ),
        BookEntity(
            id = "book_kisw_f3",
            title = "Kiswahili Form 3",
            subject = "Kiswahili",
            formLevel = "Form 3",
            author = "Mwl. Hamisi B. Kitula",
            publisher = "Tanzania Publishing House",
            year = 2023,
            pages = 198,
            fileSize = "4.5 MB",
            rating = 4.9f,
            coverColor = 0xFF0D9488,
            isDownloaded = false,
            isFavorite = true,
            description = "Mwongozo kamili wa Kiswahili Kidato cha Tatu: Sarufi, Uakifishaji, Fasihi Simulizi na Andishi, Ushairi, Riwaya, Tamthiliya, na Utunzi wa Barua na Insha.",
            pdfContent = """
SURA YA KWANZA: FASIHI SIMULIZI NA VIPENGELE VYAKE
Ukurasa 1: Dhana ya Fasihi
Fasihi ni sanaa inayotumia lugha kuwasilisha hisia, mawazo na ujumbe unaohusu maisha ya jamii.
Aina kuu mbili za Fasihi:
1. Fasihi Simulizi (Oral Literature): Huwasilishwa kwa njia ya mdomo kutoka kizazi kimoja hadi kingine.
2. Fasihi Andishi (Written Literature): Huwasilishwa kwa njia ya maandishi.

Ukurasa 2: Tanzu za Fasihi Simulizi
1. Hadithi (Ngano, visasili, vigano, hekaya).
2. Ushairi Simulizi (Nyimbo, ngonjera, maghani, tenzi simulizi).
3. Semi (Methali, misemo, vitendawili, mafumbo, nahau).
4. Maigizo (Michezo ya jukwaani, ngoma, vichekesho, malumbano ya utani).

Ukurasa 3: Sarufi - Miundo ya Sentensi
Aina za Sentensi katika lugha ya Kiswahili:
1. Sentensi Sahili: Inayo kitenzi kikuu kimoja tu. (Mfano: Neema anasoma kitabu.)
2. Sentensi Ambatano: Muungano wa sentensi mbili au zaidi sahili zilizounganishwa na viunganishi kama vile: lakini, na, au.
3. Sentensi Changamano: Inayoundwa na kishazi kikuu kimoja na kishazi tegemezi kimoja au zaidi. (Mfano: Mtoto aliyefaulu mtihani amepata zawadi.)
            """.trimIndent()
        )
    )

    fun getInitialQuizzes(): List<QuizEntity> = listOf(
        QuizEntity(
            id = "quiz_daily_challenge",
            title = "Daily Challenge: General Science & Math",
            subject = "Mathematics",
            formLevel = "Form 4",
            topic = "CSEE Examination Preparation",
            difficulty = "Medium",
            questionCount = 5,
            isDailyChallenge = true
        ),
        QuizEntity(
            id = "quiz_phys_f2_motion",
            title = "Physics: Force and Motion",
            subject = "Physics",
            formLevel = "Form 2",
            topic = "Forces, Velocity and Acceleration",
            difficulty = "Easy",
            questionCount = 5
        ),
        QuizEntity(
            id = "quiz_chem_f3_titration",
            title = "Chemistry: Volumetric Analysis",
            subject = "Chemistry",
            formLevel = "Form 3",
            topic = "Acids, Bases and Indicators",
            difficulty = "Medium",
            questionCount = 5
        ),
        QuizEntity(
            id = "quiz_bio_f4_genetics",
            title = "Biology: Genetics & Heredity",
            subject = "Biology",
            formLevel = "Form 4",
            topic = "Mendelian Genetics and Monohybrid Cross",
            difficulty = "Hard",
            questionCount = 5
        )
    )

    fun getInitialQuizQuestions(): List<QuizQuestionEntity> = listOf(
        // Daily Challenge Questions
        QuizQuestionEntity(
            id = "q_daily_1",
            quizId = "quiz_daily_challenge",
            questionNumber = 1,
            questionText = "If 3x + 5 = 20, what is the value of x?",
            optionA = "3",
            optionB = "5",
            optionC = "7",
            optionD = "15",
            correctAnswerIndex = 1,
            explanation = "Subtract 5 from both sides: 3x = 15. Divide by 3: x = 5."
        ),
        QuizQuestionEntity(
            id = "q_daily_2",
            quizId = "quiz_daily_challenge",
            questionNumber = 2,
            questionText = "What is the SI unit of electric current?",
            optionA = "Volt",
            optionB = "Ohm",
            optionC = "Ampere",
            optionD = "Coulomb",
            correctAnswerIndex = 2,
            explanation = "The SI unit of electric current is the Ampere (A), measured using an ammeter."
        ),
        QuizQuestionEntity(
            id = "q_daily_3",
            quizId = "quiz_daily_challenge",
            questionNumber = 3,
            questionText = "Which organelle is considered the 'powerhouse of the cell'?",
            optionA = "Ribosome",
            optionB = "Mitochondrion",
            optionC = "Nucleus",
            optionD = "Endoplasmic Reticulum",
            correctAnswerIndex = 1,
            explanation = "Mitochondria produce ATP through cellular respiration, supplying energy to the cell."
        ),
        QuizQuestionEntity(
            id = "q_daily_4",
            quizId = "quiz_daily_challenge",
            questionNumber = 4,
            questionText = "What color does phenolphthalein turn in an alkaline solution?",
            optionA = "Colorless",
            optionB = "Blue",
            optionC = "Pink",
            optionD = "Yellow",
            correctAnswerIndex = 2,
            explanation = "Phenolphthalein indicator is colorless in acidic solutions and turns distinct pink in basic/alkaline solutions."
        ),
        QuizQuestionEntity(
            id = "q_daily_5",
            quizId = "quiz_daily_challenge",
            questionNumber = 5,
            questionText = "What is the capital city of Tanzania?",
            optionA = "Dar es Salaam",
            optionB = "Dodoma",
            optionC = "Arusha",
            optionD = "Mwanza",
            correctAnswerIndex = 1,
            explanation = "Dodoma is the official political capital city of Tanzania."
        ),
        // Physics Force and Motion Questions
        QuizQuestionEntity(
            id = "q_phys_1",
            quizId = "quiz_phys_f2_motion",
            questionNumber = 1,
            questionText = "According to Newton's First Law of Motion, an object at rest will remain at rest unless acted upon by:",
            optionA = "Internal force",
            optionB = "Unbalanced external force",
            optionC = "Gravitational acceleration only",
            optionD = "Friction alone",
            correctAnswerIndex = 1,
            explanation = "Newton's first law states that a body remains in its state of rest or uniform motion unless compelled to change that state by an external net unbalanced force."
        ),
        QuizQuestionEntity(
            id = "q_phys_2",
            quizId = "quiz_phys_f2_motion",
            questionNumber = 2,
            questionText = "A car accelerates from rest to 20 m/s in 4 seconds. What is its acceleration?",
            optionA = "5 m/s²",
            optionB = "10 m/s²",
            optionC = "80 m/s²",
            optionD = "4 m/s²",
            correctAnswerIndex = 0,
            explanation = "Acceleration a = (v - u) / t = (20 - 0) / 4 = 5 m/s²."
        ),
        QuizQuestionEntity(
            id = "q_phys_3",
            quizId = "quiz_phys_f2_motion",
            questionNumber = 3,
            questionText = "What is the weight of a 10 kg mass on Earth (taking g = 9.8 m/s²)?",
            optionA = "10 N",
            optionB = "49 N",
            optionC = "98 N",
            optionD = "980 N",
            correctAnswerIndex = 2,
            explanation = "Weight W = m × g = 10 kg × 9.8 m/s² = 98 N."
        ),
        QuizQuestionEntity(
            id = "q_phys_4",
            quizId = "quiz_phys_f2_motion",
            questionNumber = 4,
            questionText = "The efficiency of a practical simple machine is always:",
            optionA = "Greater than 100%",
            optionB = "Equal to 100%",
            optionC = "Less than 100%",
            optionD = "Zero",
            correctAnswerIndex = 2,
            explanation = "Because some energy is always lost overcoming friction and lifting moving parts, practical efficiency is strictly less than 100%."
        ),
        QuizQuestionEntity(
            id = "q_phys_5",
            quizId = "quiz_phys_f2_motion",
            questionNumber = 5,
            questionText = "Which principle explains why an iron ship floats in seawater?",
            optionA = "Pascal's Principle",
            optionB = "Archimedes' Principle",
            optionC = "Bernoulli's Principle",
            optionD = "Hooke's Law",
            correctAnswerIndex = 1,
            explanation = "Archimedes' Principle states that buoyant upthrust equals weight of displaced fluid. The hollow shape displaces a volume of water whose weight equals the total weight of the ship."
        )
    )

    fun getInitialPastPapers(): List<PastPaperEntity> = listOf(
        PastPaperEntity(
            id = "pp_math_f4_2024",
            title = "CSEE Mathematics Past Paper",
            subject = "Mathematics",
            formLevel = "Form 4",
            year = 2024,
            examType = "CSEE NECTA",
            fileSize = "2.1 MB",
            isDownloaded = true,
            isSaved = true,
            paperContent = "National Examinations Council of Tanzania (NECTA) - Form Four Certificate of Secondary Education Examination (CSEE) 2024. Basic Mathematics Paper 1: Section A (60 marks) 10 questions; Section B (40 marks) 4 questions on Functions, Linear Programming, Circles, and Trigonometry."
        ),
        PastPaperEntity(
            id = "pp_phys_f4_2023",
            title = "CSEE Physics Paper 1",
            subject = "Physics",
            formLevel = "Form 4",
            year = 2023,
            examType = "CSEE NECTA",
            fileSize = "1.8 MB",
            isDownloaded = false,
            isSaved = true,
            paperContent = "NECTA Form Four Examination 2023 - Physics 1. Contains questions on Mechanics, Heat, Waves, Electricity, Magnetism, and Radioactivity."
        ),
        PastPaperEntity(
            id = "pp_bio_f4_2023",
            title = "CSEE Biology Paper 1",
            subject = "Biology",
            formLevel = "Form 4",
            year = 2023,
            examType = "CSEE NECTA",
            fileSize = "2.4 MB",
            isDownloaded = false,
            isSaved = false,
            paperContent = "NECTA Form 4 Biology 2023: Section A Multiple Choice; Section B Short Answers on Digestion, Genetics, and Excretion; Section C Essay on Environmental Conservation and Disease Prevention."
        ),
        PastPaperEntity(
            id = "pp_adv_math_f6_2023",
            title = "ACSEE Advanced Mathematics 1",
            subject = "Mathematics",
            formLevel = "Form 6",
            year = 2023,
            examType = "ACSEE NECTA",
            fileSize = "3.2 MB",
            isDownloaded = false,
            isSaved = false,
            paperContent = "Advanced Certificate of Secondary Education Examination (ACSEE) 2023 - Advanced Mathematics Paper 1: Complex numbers, Trigonometry, Calculus, and Coordinate Geometry."
        ),
        PastPaperEntity(
            id = "pp_kisw_f2_2024",
            title = "FTNA Kiswahili Paper",
            subject = "Kiswahili",
            formLevel = "Form 2",
            year = 2024,
            examType = "FTNA NECTA",
            fileSize = "1.5 MB",
            isDownloaded = true,
            isSaved = false,
            paperContent = "Mtihani wa Taifa wa Kidato cha Pili (FTNA) 2024 - Kiswahili. Sehemu A: Ufahamu na Ufupisho; Sehemu B: Sarufi na Matumizi ya Lugha; Sehemu C: Fasihi Simulizi na Utunzi."
        )
    )

    fun getInitialRevisionNotes(): List<RevisionNoteEntity> = listOf(
        RevisionNoteEntity(
            id = "note_f4_quadratics",
            title = "Quadratic Equations Master Summary",
            subject = "Mathematics",
            formLevel = "Form 4",
            topic = "Algebra",
            summary = "Standard form: ax² + bx + c = 0. Methods of solution: 1. Factorization, 2. Completing the square, 3. Quadratic formula: x = (-b ± √(b² - 4ac)) / 2a. Discriminant Δ = b² - 4ac determines nature of roots (Δ > 0 real distinct, Δ = 0 real equal, Δ < 0 complex/no real roots).",
            keyFormulas = "x = [-b ± √(b² - 4ac)] / 2a\nSum of roots = -b/a\nProduct of roots = c/a",
            examTips = "Always check signs when plugging negative values of b into the formula. Verify answers by substituting back into original equation."
        ),
        RevisionNoteEntity(
            id = "note_f2_pressure",
            title = "Pressure in Liquids & Hydraulic Press",
            subject = "Physics",
            formLevel = "Form 2",
            topic = "Pressure",
            summary = "Pressure in liquids is independent of shape or volume of container; depends only on density ρ, gravity g, and depth h. Formula: P = ρ g h. In hydraulic press: F₁ / A₁ = F₂ / A₂. Allows small effort on small piston to lift heavy load on large piston.",
            keyFormulas = "P = ρ g h\nF₁ / A₁ = F₂ / A₂\nPressure = Force / Area",
            examTips = "Ensure depth is in meters and density in kg/m³. If atmospheric pressure is mentioned, total pressure = P_atm + ρgh."
        ),
        RevisionNoteEntity(
            id = "note_f4_genetics",
            title = "Genetics Key Terminology & Crosses",
            subject = "Biology",
            formLevel = "Form 4",
            topic = "Genetics",
            summary = "Key concepts: Dominant vs Recessive alleles; Homozygous (identical alleles e.g. BB, bb) vs Heterozygous (different alleles e.g. Bb). Sex-linked inheritance traits carried on X chromosome. ABO blood group system determined by multiple alleles (Iᴬ, Iᴮ, i).",
            keyFormulas = "Phenotypic ratio in F2 = 3 : 1\nGenotypic ratio in F2 = 1 : 2 : 1",
            examTips = "Always draw clear genetic diagrams labeling Parental phenotypes, Parental genotypes, Gametes, and F1/F2 offspring genotypes."
        )
    )

    fun getInitialUser(): UserAccountEntity = UserAccountEntity(
        id = "student_user_1",
        name = "Athanase Mushobozi",
        email = "athanasemushobozi@gmail.com",
        role = "STUDENT",
        selectedForm = "Form 4",
        favoriteSubjects = "Mathematics, Physics, Chemistry, Biology",
        booksReadCount = 14,
        booksDownloadedCount = 4,
        quizzesCompletedCount = 12,
        averageScore = 88
    )
}
