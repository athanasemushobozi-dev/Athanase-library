package com.example.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMessage(
    val id: String,
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class MessageSender {
    STUDENT,
    AI_TUTOR
}

class AiTutorService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun askTutor(
        studentQuery: String,
        subject: String,
        formLevel: String,
        isSwahili: Boolean
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val response = callGeminiApi(apiKey, studentQuery, subject, formLevel, isSwahili)
                if (response.isNotBlank()) {
                    return@withContext response
                }
            } catch (e: Exception) {
                // Fallback to local curriculum engine if network/API fails
            }
        }

        // High quality offline / default educational response tailored for Tanzanian students
        getCurriculumTutorResponse(studentQuery, subject, formLevel, isSwahili)
    }

    private fun callGeminiApi(
        apiKey: String,
        prompt: String,
        subject: String,
        formLevel: String,
        isSwahili: Boolean
    ): String {
        val languageInstruction = if (isSwahili) {
            "Jibu kwa lugha ya Kiswahili fasaha inayotumika katika mitaala ya sekondari ya Tanzania (TIE / NECTA)."
        } else {
            "Respond in clear, accessible English adhering to the Tanzanian secondary curriculum (TIE / NECTA)."
        }

        val systemPrompt = """
            You are the dedicated ATHANASE LIBRARY AI Tutor for Tanzanian secondary school students ($formLevel, Subject: $subject).
            $languageInstruction
            Structure your answer cleanly:
            1. Clear Definition / Direct Explanation
            2. Step-by-Step Breakdown or Working
            3. Real-world Example (relevant to East Africa/Tanzania where possible)
            4. Quick Practice Question or Examination Tip for NECTA
        """.trimIndent()

        val jsonRequest = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", "$systemPrompt\n\nStudent Query: $prompt"))
                    })
                })
            })
        }

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = jsonRequest.toString().toRequestBody(mediaType)
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return ""
            val body = response.body?.string() ?: return ""
            val root = JSONObject(body)
            val candidates = root.optJSONArray("candidates") ?: return ""
            if (candidates.length() == 0) return ""
            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content") ?: return ""
            val parts = content.optJSONArray("parts") ?: return ""
            if (parts.length() == 0) return ""
            return parts.getJSONObject(0).optString("text", "")
        }
    }

    private fun getCurriculumTutorResponse(
        query: String,
        subject: String,
        formLevel: String,
        isSwahili: Boolean
    ): String {
        val q = query.lowercase()

        if (isSwahili) {
            return when {
                q.contains("photosynthesis") || q.contains("usanisinuru") -> """
                    🌿 **USANISINURU (PHOTOSYNTHESIS) - $formLevel $subject**
                    
                    **1. Maana:**
                    Usanisinuru ni mchakato ambao mimea ya kijani hutumia mwanga wa jua, maji (H₂O), na hewa ya ukaa (Carbon Dioxide - CO₂) kutengeneza chakula (Glukosi - C₆H₁₂O₆) na kutoa hewa ya oksijeni (O₂).
                    
                    **2. Mlinganyo wa Kikemia:**
                    6CO₂ + 6H₂O + (Nguvu ya Jua + Klorofili) ➔ C₆H₁₂O₆ + 6O₂
                    
                    **3. Mahitaji Muhimu:**
                    • Mwanga wa jua
                    • Klorofili (chembechembe za kijani)
                    • Maji kutoka mizizini
                    • Hewa ya ukaa kutoka angani kupitia stomata
                    
                    **4. Dokezo la Mtihani (NECTA Tip):**
                    Maswali ya NECTA mara nyingi huuliza kuhusu majaribio ya kuthibitisha uwepo wa wanga katika jani (Starch test using Iodine solution).
                """.trimIndent()

                q.contains("newton") || q.contains("sheria") -> """
                    ⚡ **SHERIA ZA MWENDO ZA NEWTON - $formLevel $subject**
                    
                    **Sheria ya Pili ya Newton (Newton's Second Law):**
                    Kasi ya mabadiliko ya kani ya mwendo (momentum) inawiana moja kwa moja na kani (force) inayotumika, na inatokea katika mwelekeo wa kani hiyo.
                    
                    **Kanuni (Formula):**
                    F = m × a
                    • F = Kani (Force) katika Newtons (N)
                    • m = Masi (Mass) katika Kilograms (kg)
                    • a = Mchapuko (Acceleration) katika m/s²
                    
                    **Mfano wa Hesabu:**
                    Tafuta kani inayohitajika kutoa mchapuko wa 3 m/s² kwenye gari lenye uzito wa kilo 800:
                    F = 800 kg × 3 m/s² = 2,400 N.
                """.trimIndent()

                else -> """
                    📘 **MTAZAMO WA ELIMU - ATHANASE LIBRARY AI TUTOR**
                    **Darasa:** $formLevel | **Somo:** $subject
                    
                    Kuhusu swali lako: "$query"
                    
                    **Ufafanuzi:**
                    Katika mtaala wa sekondari wa Tanzania (NECTA), mada hii inasisitiza kuelewa misingi mikuu, fomula husika, na mifano ya uhalisia.
                    
                    **Hatua za Kufuata:**
                    1. Tambua vigezo ulivyopewa (Given variables).
                    2. Andika fomula au kanuni husika.
                    3. Kokotoa hatua kwa hatua bila kuruka mantiki.
                    4. Hakikisha majibu yana vizio sahihi (SI units).
                    
                    *Je, ungependa mifano zaidi ya maswali ya mtihani wa NECTA kwenye mada hii?*
                """.trimIndent()
            }
        }

        return when {
            q.contains("photosynthesis") -> """
                🌿 **PHOTOSYNTHESIS EXPLANATION - $formLevel $subject**
                
                **1. Definition:**
                Photosynthesis is the biological process by which green plants, algae, and certain bacteria synthesize carbohydrates (glucose) from carbon dioxide (CO₂) and water (H₂O) using sunlight trapped by chlorophyll, releasing oxygen (O₂) as a byproduct.
                
                **2. Balanced Chemical Equation:**
                6CO₂ + 6H₂O ➔ (Sunlight / Chlorophyll) ➔ C₆H₁₂O₆ + 6O₂
                
                **3. Two Main Stages:**
                • **Light-dependent reaction (Photolysis of water):** Takes place in the thylakoid membranes of chloroplasts where light energy splits water molecules into hydrogen ions and oxygen.
                • **Light-independent reaction (Calvin Cycle):** Takes place in the stroma where carbon dioxide is fixed to form glucose.
                
                **4. NECTA Examination Focus:**
                Common questions ask to describe the starch test on a variegated leaf:
                1. Boil leaf in water (kills protoplasm).
                2. Boil in methylated spirit/alcohol in water bath (decolorizes chlorophyll).
                3. Dip in warm water (softens leaf).
                4. Add drops of Iodine solution: Blue-black indicates presence of starch.
            """.trimIndent()

            q.contains("newton") || q.contains("second law") -> """
                ⚡ **NEWTON'S LAWS OF MOTION - $formLevel $subject**
                
                **Newton's Second Law of Motion states:**
                "The rate of change of momentum of an object is directly proportional to the applied net external force and takes place in the direction of the force."
                
                **Mathematical Derivation:**
                Rate of change of momentum = (mv - mu) / t = m(v - u)/t
                Since acceleration a = (v - u) / t:
                F ∝ m·a ➔ **F = m·a**
                
                Where:
                • F = Force in Newtons (N)
                • m = Mass in kilograms (kg)
                • a = Acceleration in meters per second squared (m/s²)
                
                **Step-by-Step Example:**
                *Problem:* Calculate the force required to accelerate a 1,200 kg vehicle at 2.5 m/s².
                *Solution:*
                F = m × a
                F = 1200 kg × 2.5 m/s² = **3,000 N** (or 3 kN).
                
                **Practice Question for You:**
                What acceleration is produced when a net force of 45 N acts on a mass of 9 kg? (Answer: a = F/m = 45/9 = 5 m/s²).
            """.trimIndent()

            q.contains("practice") || q.contains("question") -> """
                📝 **PRACTICE QUESTIONS FOR $formLevel $subject**
                
                Here are 3 NECTA-style examination questions to test your understanding:
                
                1. **Question 1:** Define the core concept and state two real-life applications in Tanzania.
                2. **Question 2 (Calculation):** A body of mass 5 kg moves with an initial velocity of 10 m/s and reaches 30 m/s in 5 seconds. Determine:
                   (a) The acceleration.
                   (b) The net force acting on the body.
                3. **Question 3:** Explain why wearing seatbelts is essential using Newton's First Law of Inertia.
                
                *Type "Solve question 2" or ask any follow-up to see full step-by-step solutions!*
            """.trimIndent()

            q.contains("solve") || q.contains("math") || q.contains("algebra") -> """
                📐 **STEP-BY-STEP SOLUTION - $formLevel $subject**
                
                Let's solve the problem systematically:
                
                **Step 1: Identify Given Information**
                State all given parameters and identify the target variable.
                
                **Step 2: Choose the Correct Formula**
                For Quadratic equations: ax² + bx + c = 0
                x = [-b ± √(b² - 4ac)] / 2a
                
                **Step 3: Substitute & Compute**
                Substitute values into the formula and simplify terms inside the square root first.
                
                **Step 4: Check Validity**
                Substitute your solutions back into the original equation to verify both sides balance.
                
                *You can type any specific equation (e.g., "Solve 2x² + 5x - 3 = 0") and I will work through every step with you!*
            """.trimIndent()

            else -> """
                🎓 **ATHANASE LIBRARY AI TUTOR**
                **Target:** $formLevel | **Subject:** $subject
                
                Regarding your question: "$query"
                
                **Key Concept Summary:**
                This topic is central to the NECTA $formLevel $subject syllabus. Understanding the fundamental definitions, principles, and experimental proofs will help you score Grade A marks in your national examinations.
                
                **Study Advice:**
                1. Read the dedicated chapter in **ATHANASE LIBRARY** books.
                2. Attempt the related Form $formLevel quizzes in the Quiz tab.
                3. Solve past paper questions from 2020–2024 to become familiar with question phrasing.
                
                *Would you like detailed notes, formulas, or practice questions on this topic?*
            """.trimIndent()
        }
    }
}
