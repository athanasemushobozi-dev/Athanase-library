package com.example.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.example.data.model.AppLanguage
import com.example.ui.components.AppTopHeader
import com.example.ui.screens.admin.AdminDashboardScreen
import com.example.ui.screens.aitutor.AiTutorScreen
import com.example.ui.screens.book.BookDetailScreen
import com.example.ui.screens.book.PdfReaderScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.library.LibraryScreen
import com.example.ui.screens.notes.RevisionNotesScreen
import com.example.ui.screens.pastpapers.PastPapersScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.quiz.QuizScreen
import com.example.ui.theme.AmberGold
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.viewmodel.MainViewModel

sealed class Screen(val route: String, val titleEn: String, val titleSw: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    object Home : Screen("home", "Home", "Nyumbani", Icons.Filled.Home, Icons.Outlined.Home)
    object Library : Screen("library", "Library", "Maktaba", Icons.Filled.MenuBook, Icons.Outlined.MenuBook)
    object Quiz : Screen("quiz", "Quiz", "Majaribio", Icons.Filled.Quiz, Icons.Outlined.Quiz)
    object AiTutor : Screen("ai_tutor", "AI Tutor", "Mwalimu AI", Icons.Filled.Psychology, Icons.Outlined.Psychology)
    object Profile : Screen("profile", "Profile", "Wasifu", Icons.Filled.Person, Icons.Outlined.Person)

    // Non-bottom bar screens
    object BookDetail : Screen("book_detail", "Book Details", "Maelezo ya Kitabu", Icons.Default.Book, Icons.Default.Book)
    object PdfReader : Screen("pdf_reader", "Reader", "Msomaji", Icons.Default.MenuBook, Icons.Default.MenuBook)
    object PastPapers : Screen("past_papers", "Past Papers", "Mitihani ya Nyuma", Icons.Default.HistoryEdu, Icons.Default.HistoryEdu)
    object RevisionNotes : Screen("revision_notes", "Notes", "Muhtasari", Icons.Default.Lightbulb, Icons.Default.Lightbulb)
    object AdminDashboard : Screen("admin_dashboard", "Admin", "Msimamizi", Icons.Default.AdminPanelSettings, Icons.Default.AdminPanelSettings)
}

@Composable
fun AppNavigation(
    viewModel: MainViewModel,
    navController: NavHostController = rememberNavController()
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Home.route

    val language by viewModel.language.collectAsState()
    val isSwahili = language == AppLanguage.KISWAHILI
    val currentUser by viewModel.currentUser.collectAsState()
    val userRole = currentUser?.role ?: "STUDENT"

    val selectedBook by viewModel.selectedBook.collectAsState()
    val notificationMsg by viewModel.notificationMessage.collectAsState()

    val bottomBarScreens = listOf(
        Screen.Home,
        Screen.Library,
        Screen.Quiz,
        Screen.AiTutor,
        Screen.Profile
    )

    val showBottomBar = currentRoute in bottomBarScreens.map { it.route }
    val showTopHeader = showBottomBar && currentRoute != Screen.BookDetail.route && currentRoute != Screen.PdfReader.route

    Scaffold(
        topBar = {
            if (showTopHeader) {
                AppTopHeader(
                    title = "ATHANASE LIBRARY",
                    subtitle = "Learn. Read. Practice. Succeed.",
                    isSwahili = isSwahili,
                    onLanguageToggle = { viewModel.toggleLanguage() },
                    userRole = userRole,
                    onRoleToggle = { viewModel.toggleUserRole() }
                )
            }
        },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    bottomBarScreens.forEach { screen ->
                        val isSelected = currentRoute == screen.route
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(Screen.Home.route) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.titleEn,
                                    tint = if (isSelected) EmeraldAccent else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            label = {
                                Text(
                                    text = if (isSwahili) screen.titleSw else screen.titleEn,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) EmeraldAccent else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            modifier = Modifier.testTag("nav_item_${screen.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route,
                modifier = Modifier.fillMaxSize()
            ) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToBookDetail = { book ->
                            viewModel.selectBook(book)
                            navController.navigate(Screen.BookDetail.route)
                        },
                        onNavigateToReader = { book ->
                            viewModel.selectBook(book)
                            navController.navigate(Screen.PdfReader.route)
                        },
                        onNavigateToQuiz = {
                            navController.navigate(Screen.Quiz.route)
                        },
                        onNavigateToPastPapers = {
                            navController.navigate(Screen.PastPapers.route)
                        },
                        onNavigateToNotes = {
                            navController.navigate(Screen.RevisionNotes.route)
                        },
                        onNavigateToLibrary = {
                            navController.navigate(Screen.Library.route)
                        }
                    )
                }

                composable(Screen.Library.route) {
                    LibraryScreen(
                        viewModel = viewModel,
                        onNavigateToBookDetail = { book ->
                            viewModel.selectBook(book)
                            navController.navigate(Screen.BookDetail.route)
                        },
                        onNavigateToReader = { book ->
                            viewModel.selectBook(book)
                            navController.navigate(Screen.PdfReader.route)
                        }
                    )
                }

                composable(Screen.Quiz.route) {
                    QuizScreen(viewModel = viewModel)
                }

                composable(Screen.AiTutor.route) {
                    AiTutorScreen(viewModel = viewModel)
                }

                composable(Screen.Profile.route) {
                    ProfileScreen(
                        viewModel = viewModel,
                        onNavigateToPastPapers = { navController.navigate(Screen.PastPapers.route) },
                        onNavigateToNotes = { navController.navigate(Screen.RevisionNotes.route) },
                        onNavigateToAdmin = { navController.navigate(Screen.AdminDashboard.route) }
                    )
                }

                composable(Screen.BookDetail.route) {
                    if (selectedBook != null) {
                        BookDetailScreen(
                            book = selectedBook!!,
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() },
                            onOpenReader = {
                                navController.navigate(Screen.PdfReader.route)
                            }
                        )
                    }
                }

                composable(Screen.PdfReader.route) {
                    if (selectedBook != null) {
                        PdfReaderScreen(
                            book = selectedBook!!,
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }

                composable(Screen.PastPapers.route) {
                    PastPapersScreen(
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Screen.RevisionNotes.route) {
                    RevisionNotesScreen(
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminDashboard.route) {
                    AdminDashboardScreen(
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }
            }

            // In-App Push Notification Banner
            AnimatedVisibility(
                visible = notificationMsg != null,
                enter = slideInVertically(initialOffsetY = { -it }),
                exit = slideOutVertically(targetOffsetY = { -it }),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp)
            ) {
                if (notificationMsg != null) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.clearNotificationMessage() },
                        color = NavyPrimary,
                        shape = RoundedCornerShape(14.dp),
                        shadowElevation = 8.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = null,
                                tint = AmberGold,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = notificationMsg!!,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.clearNotificationMessage() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    tint = Color.White.copy(alpha = 0.7f),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
