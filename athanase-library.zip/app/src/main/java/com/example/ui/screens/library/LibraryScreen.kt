package com.example.ui.screens.library

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BookEntity
import com.example.data.model.AppLanguage
import com.example.data.model.FormLevel
import com.example.data.model.Subject
import com.example.ui.components.BookCardItem
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun LibraryScreen(
    viewModel: MainViewModel,
    onNavigateToBookDetail: (BookEntity) -> Unit,
    onNavigateToReader: (BookEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val books by viewModel.filteredBooks.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedForm by viewModel.selectedFormFilter.collectAsState()
    val selectedSubject by viewModel.selectedSubjectFilter.collectAsState()
    val currentTab by viewModel.libraryTabFilter.collectAsState()
    val language by viewModel.language.collectAsState()
    val isSwahili = language == AppLanguage.KISWAHILI

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("library_screen")
    ) {
        // Search & Filter Header
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = {
                        Text(
                            text = if (isSwahili) "Tafuta vitabu, waandishi au mada..."
                            else "Search books, authors, topics...",
                            fontSize = 14.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = NavyPrimary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear search"
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldAccent,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("library_search_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Library Tabs: All, Downloaded, Favorites
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val tabs = listOf(
                        "ALL" to if (isSwahili) "Vitabu Vyote" else "All Books",
                        "DOWNLOADED" to if (isSwahili) "Vilivyopakuliwa" else "Downloaded",
                        "FAVORITES" to if (isSwahili) "Vipendwa" else "Favorites"
                    )

                    tabs.forEach { (key, label) ->
                        val isSelected = currentTab == key
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { viewModel.setLibraryTab(key) }
                                .testTag("library_tab_$key"),
                            color = if (isSelected) NavyPrimary else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Form Level Filter Chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(FormLevel.entries) { form ->
                        val isSelected = selectedForm == form
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setFormFilter(form) },
                            label = {
                                Text(
                                    text = form.getTitle(isSwahili),
                                    fontSize = 12.sp
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldAccent,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                // Subject Filter Chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(Subject.entries.take(8)) { sub ->
                        val isSelected = selectedSubject == sub
                        AssistChip(
                            onClick = {
                                viewModel.setSubjectFilter(if (isSelected) Subject.ALL else sub)
                            },
                            label = {
                                Text(
                                    text = sub.getTitle(isSwahili),
                                    fontSize = 11.sp,
                                    color = if (isSelected) EmeraldAccent else MaterialTheme.colorScheme.onSurface
                                )
                            },
                            border = if (isSelected) BorderStroke(1.5.dp, EmeraldAccent)
                            else BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        )
                    }
                }
            }
        }

        // Result Count & Book List
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isSwahili) "Matokeo: vitabu ${books.size}" else "Showing ${books.size} books",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (selectedForm != FormLevel.ALL || selectedSubject != Subject.ALL || searchQuery.isNotBlank()) {
                TextButton(
                    onClick = {
                        viewModel.setFormFilter(FormLevel.ALL)
                        viewModel.setSubjectFilter(Subject.ALL)
                        viewModel.setSearchQuery("")
                    }
                ) {
                    Text(
                        text = if (isSwahili) "Futa Vichungi" else "Clear Filters",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        if (books.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.SearchOff,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (isSwahili) "Hakuna kitabu kilichopatikana" else "No books found",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isSwahili) "Jaribu kubadilisha vigezo vya utafutaji au kidato chako."
                        else "Try adjusting your search query, Form, or Subject filters.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    FilledTonalButton(
                        onClick = {
                            viewModel.setFormFilter(FormLevel.ALL)
                            viewModel.setSubjectFilter(Subject.ALL)
                            viewModel.setSearchQuery("")
                            viewModel.setLibraryTab("ALL")
                        }
                    ) {
                        Text(if (isSwahili) "Onyesha Vitabu Vyote" else "Reset & Show All Books")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(books, key = { it.id }) { book ->
                    BookCardItem(
                        book = book,
                        onClick = { onNavigateToBookDetail(book) },
                        onFavoriteToggle = { viewModel.toggleFavorite(book) },
                        onDownloadToggle = { viewModel.toggleDownload(book) },
                        isSwahili = isSwahili
                    )
                }
            }
        }
    }
}
