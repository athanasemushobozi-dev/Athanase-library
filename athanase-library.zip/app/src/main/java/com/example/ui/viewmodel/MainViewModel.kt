package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiTutorService
import com.example.ai.ChatMessage
import com.example.ai.MessageSender
import com.example.data.local.*
import com.example.data.model.AppLanguage
import com.example.data.model.FormLevel
import com.example.data.model.Subject
import com.example.data.model.UserRole
import com.example.data.repository.AppRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {
    val repository = AppRepository(application)
    private val aiService = AiTutorService()

    // Preferences & Settings State
    private val _language = MutableStateFlow(AppLanguage.ENGLISH)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _notificationsEnabled = MutableStateFlow(true)
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    private val _notificationMessage = MutableStateFlow<String?>(null)
    val notificationMessage: StateFlow<String?> = _notificationMessage.asStateFlow()

    // Current User
    val currentUser: StateFlow<UserAccountEntity?> = repository.currentUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Library Filtering & Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFormFilter = MutableStateFlow(FormLevel.ALL)
    val selectedFormFilter: StateFlow<FormLevel> = _selectedFormFilter.asStateFlow()

    private val _selectedSubjectFilter = MutableStateFlow(Subject.ALL)
    val selectedSubjectFilter: StateFlow<Subject> = _selectedSubjectFilter.asStateFlow()

    private val _libraryTabFilter = MutableStateFlow("ALL") // ALL, DOWNLOADED, FAVORITES
    val libraryTabFilter: StateFlow<String> = _libraryTabFilter.asStateFlow()

    // Books stream
    val allPublishedBooks: StateFlow<List<BookEntity>> = repository.allPublishedBooks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAdminBooks: StateFlow<List<BookEntity>> = repository.allAdminBooks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloadedBooks: StateFlow<List<BookEntity>> = repository.downloadedBooks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteBooks: StateFlow<List<BookEntity>> = repository.favoriteBooks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentReadingProgress: StateFlow<List<ReadingProgressEntity>> = repository.allRecentProgress
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered books for Library screen
    val filteredBooks: StateFlow<List<BookEntity>> = combine(
        allPublishedBooks,
        searchQuery,
        selectedFormFilter,
        selectedSubjectFilter,
        libraryTabFilter
    ) { books, query, form, subject, tab ->
        var list = books

        if (tab == "DOWNLOADED") {
            list = list.filter { it.isDownloaded }
        } else if (tab == "FAVORITES") {
            list = list.filter { it.isFavorite }
        }

        if (form != FormLevel.ALL) {
            list = list.filter { it.formLevel.equals(form.displayNameEn, ignoreCase = true) || it.formLevel.contains(form.shortCode, ignoreCase = true) }
        }

        if (subject != Subject.ALL) {
            list = list.filter { it.subject.equals(subject.displayNameEn, ignoreCase = true) || it.subject.contains(subject.name, ignoreCase = true) }
        }

        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                it.subject.lowercase().contains(q) ||
                it.formLevel.lowercase().contains(q) ||
                it.author.lowercase().contains(q) ||
                it.description.lowercase().contains(q)
            }
        }

        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Book Selection & PDF Reader
    private val _selectedBook = MutableStateFlow<BookEntity?>(null)
    val selectedBook: StateFlow<BookEntity?> = _selectedBook.asStateFlow()

    private val _readerCurrentPage = MutableStateFlow(1)
    val readerCurrentPage: StateFlow<Int> = _readerCurrentPage.asStateFlow()

    private val _readerNightMode = MutableStateFlow(false)
    val readerNightMode: StateFlow<Boolean> = _readerNightMode.asStateFlow()

    private val _readerFontSize = MutableStateFlow(16)
    val readerFontSize: StateFlow<Int> = _readerFontSize.asStateFlow()

    private val _bookmarkedPages = MutableStateFlow<Set<Int>>(emptySet())
    val bookmarkedPages: StateFlow<Set<Int>> = _bookmarkedPages.asStateFlow()

    // Quizzes & Results
    val allQuizzes: StateFlow<List<QuizEntity>> = repository.allQuizzes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAdminQuizzes: StateFlow<List<QuizEntity>> = repository.allAdminQuizzes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dailyQuiz: StateFlow<QuizEntity?> = repository.dailyQuiz
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val quizResults: StateFlow<List<QuizResultEntity>> = repository.allQuizResults
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Quiz Session State
    private val _activeQuiz = MutableStateFlow<QuizEntity?>(null)
    val activeQuiz: StateFlow<QuizEntity?> = _activeQuiz.asStateFlow()

    private val _quizQuestions = MutableStateFlow<List<QuizQuestionEntity>>(emptyList())
    val quizQuestions: StateFlow<List<QuizQuestionEntity>> = _quizQuestions.asStateFlow()

    private val _currentQuestionIndex = MutableStateFlow(0)
    val currentQuestionIndex: StateFlow<Int> = _currentQuestionIndex.asStateFlow()

    private val _userSelectedAnswers = MutableStateFlow<Map<Int, Int>>(emptyMap()) // questionIndex -> selectedOption
    val userSelectedAnswers: StateFlow<Map<Int, Int>> = _userSelectedAnswers.asStateFlow()

    private val _quizSecondsElapsed = MutableStateFlow(0)
    val quizSecondsElapsed: StateFlow<Int> = _quizSecondsElapsed.asStateFlow()

    private val _isQuizCompleted = MutableStateFlow(false)
    val isQuizCompleted: StateFlow<Boolean> = _isQuizCompleted.asStateFlow()

    private val _lastQuizResult = MutableStateFlow<QuizResultEntity?>(null)
    val lastQuizResult: StateFlow<QuizResultEntity?> = _lastQuizResult.asStateFlow()

    private var quizTimerJob: Job? = null

    // AI Tutor State
    private val _aiSubject = MutableStateFlow(Subject.MATHEMATICS)
    val aiSubject: StateFlow<Subject> = _aiSubject.asStateFlow()

    private val _aiForm = MutableStateFlow(FormLevel.FORM_4)
    val aiForm: StateFlow<FormLevel> = _aiForm.asStateFlow()

    private val _aiMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                id = "welcome_1",
                sender = MessageSender.AI_TUTOR,
                text = "Habari! I am your ATHANASE LIBRARY AI Tutor. Select your Subject and Form, then ask any question, request step-by-step solutions, or ask for examination practice questions!"
            )
        )
    )
    val aiMessages: StateFlow<List<ChatMessage>> = _aiMessages.asStateFlow()

    private val _isAiGenerating = MutableStateFlow(false)
    val isAiGenerating: StateFlow<Boolean> = _isAiGenerating.asStateFlow()

    // Past Papers
    val allPastPapers: StateFlow<List<PastPaperEntity>> = repository.allPastPapers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Revision Notes
    val allRevisionNotes: StateFlow<List<RevisionNoteEntity>> = repository.allRevisionNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search query setters
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFormFilter(form: FormLevel) {
        _selectedFormFilter.value = form
    }

    fun setSubjectFilter(subject: Subject) {
        _selectedSubjectFilter.value = subject
    }

    fun setLibraryTab(tab: String) {
        _libraryTabFilter.value = tab
    }

    fun toggleLanguage() {
        _language.value = if (_language.value == AppLanguage.ENGLISH) AppLanguage.KISWAHILI else AppLanguage.ENGLISH
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun toggleNotifications() {
        _notificationsEnabled.value = !_notificationsEnabled.value
    }

    fun clearNotificationMessage() {
        _notificationMessage.value = null
    }

    fun triggerMockNotification(msg: String) {
        if (_notificationsEnabled.value) {
            _notificationMessage.value = msg
        }
    }

    // Book Actions
    fun selectBook(book: BookEntity) {
        _selectedBook.value = book
        viewModelScope.launch {
            val progress = repository.getProgressForBook(book.id).first()
            _readerCurrentPage.value = progress?.currentPage ?: 1
        }
    }

    fun toggleFavorite(book: BookEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(book.id, book.isFavorite)
            _selectedBook.value = _selectedBook.value?.copy(isFavorite = !book.isFavorite)
        }
    }

    fun toggleDownload(book: BookEntity) {
        viewModelScope.launch {
            repository.toggleDownload(book.id, book.isDownloaded)
            _selectedBook.value = _selectedBook.value?.copy(isDownloaded = !book.isDownloaded)
            if (!book.isDownloaded) {
                triggerMockNotification("Downloaded: ${book.title} is now available offline!")
            }
        }
    }

    // Reader Controls
    fun setReaderPage(page: Int) {
        val maxPages = _selectedBook.value?.pages ?: 10
        val clamped = page.coerceIn(1, maxPages)
        _readerCurrentPage.value = clamped
        saveCurrentReadingProgress()
    }

    fun nextPage() {
        val maxPages = _selectedBook.value?.pages ?: 10
        if (_readerCurrentPage.value < maxPages) {
            _readerCurrentPage.value += 1
            saveCurrentReadingProgress()
        }
    }

    fun prevPage() {
        if (_readerCurrentPage.value > 1) {
            _readerCurrentPage.value -= 1
            saveCurrentReadingProgress()
        }
    }

    fun toggleReaderNightMode() {
        _readerNightMode.value = !_readerNightMode.value
    }

    fun zoomIn() {
        if (_readerFontSize.value < 28) _readerFontSize.value += 2
    }

    fun zoomOut() {
        if (_readerFontSize.value > 12) _readerFontSize.value -= 2
    }

    fun toggleBookmarkCurrentPage() {
        val page = _readerCurrentPage.value
        val current = _bookmarkedPages.value.toMutableSet()
        if (current.contains(page)) current.remove(page) else current.add(page)
        _bookmarkedPages.value = current
    }

    private fun saveCurrentReadingProgress() {
        val book = _selectedBook.value ?: return
        viewModelScope.launch {
            repository.saveReadingProgress(
                ReadingProgressEntity(
                    bookId = book.id,
                    bookTitle = book.title,
                    subject = book.subject,
                    formLevel = book.formLevel,
                    currentPage = _readerCurrentPage.value,
                    totalPages = book.pages
                )
            )
        }
    }

    // Quiz Session
    fun startQuiz(quiz: QuizEntity) {
        _activeQuiz.value = quiz
        _currentQuestionIndex.value = 0
        _userSelectedAnswers.value = emptyMap()
        _quizSecondsElapsed.value = 0
        _isQuizCompleted.value = false
        _lastQuizResult.value = null

        viewModelScope.launch {
            val questions = repository.getQuestionsForQuiz(quiz.id).first()
            _quizQuestions.value = questions
            startQuizTimer()
        }
    }

    private fun startQuizTimer() {
        quizTimerJob?.cancel()
        quizTimerJob = viewModelScope.launch {
            while (!_isQuizCompleted.value) {
                delay(1000)
                _quizSecondsElapsed.value += 1
            }
        }
    }

    fun selectAnswer(optionIndex: Int) {
        val currentQ = _currentQuestionIndex.value
        val map = _userSelectedAnswers.value.toMutableMap()
        map[currentQ] = optionIndex
        _userSelectedAnswers.value = map
    }

    fun nextQuestion() {
        if (_currentQuestionIndex.value < _quizQuestions.value.size - 1) {
            _currentQuestionIndex.value += 1
        } else {
            finishQuiz()
        }
    }

    fun prevQuestion() {
        if (_currentQuestionIndex.value > 0) {
            _currentQuestionIndex.value -= 1
        }
    }

    fun finishQuiz() {
        quizTimerJob?.cancel()
        _isQuizCompleted.value = true

        val quiz = _activeQuiz.value ?: return
        val questions = _quizQuestions.value
        val answers = _userSelectedAnswers.value

        var correctCount = 0
        questions.forEachIndexed { index, question ->
            if (answers[index] == question.correctAnswerIndex) {
                correctCount++
            }
        }

        val total = questions.size.coerceAtLeast(1)
        val percentage = (correctCount * 100) / total

        val result = QuizResultEntity(
            quizId = quiz.id,
            quizTitle = quiz.title,
            formLevel = quiz.formLevel,
            subject = quiz.subject,
            score = correctCount,
            totalQuestions = total,
            percentage = percentage,
            timeTakenSeconds = _quizSecondsElapsed.value
        )

        _lastQuizResult.value = result
        viewModelScope.launch {
            repository.recordQuizResult(result)
            triggerMockNotification("Quiz Complete! You scored $percentage% in ${quiz.title}")
        }
    }

    // AI Tutor
    fun setAiSubject(subject: Subject) {
        _aiSubject.value = subject
    }

    fun setAiForm(form: FormLevel) {
        _aiForm.value = form
    }

    fun sendAiMessage(promptText: String) {
        if (promptText.isBlank()) return
        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            sender = MessageSender.STUDENT,
            text = promptText
        )
        _aiMessages.value = _aiMessages.value + userMsg
        _isAiGenerating.value = true

        viewModelScope.launch {
            val reply = aiService.askTutor(
                studentQuery = promptText,
                subject = _aiSubject.value.displayNameEn,
                formLevel = _aiForm.value.displayNameEn,
                isSwahili = _language.value == AppLanguage.KISWAHILI
            )
            val tutorMsg = ChatMessage(
                id = UUID.randomUUID().toString(),
                sender = MessageSender.AI_TUTOR,
                text = reply
            )
            _aiMessages.value = _aiMessages.value + tutorMsg
            _isAiGenerating.value = false
        }
    }

    // Past Papers & Notes
    fun togglePastPaperDownload(paper: PastPaperEntity) {
        viewModelScope.launch {
            repository.togglePastPaperDownload(paper.id, paper.isDownloaded)
            if (!paper.isDownloaded) {
                triggerMockNotification("Past Paper: ${paper.title} saved for offline study!")
            }
        }
    }

    fun togglePastPaperSave(paper: PastPaperEntity) {
        viewModelScope.launch {
            repository.togglePastPaperSaved(paper.id, paper.isSaved)
        }
    }

    fun toggleNoteSaved(note: RevisionNoteEntity) {
        viewModelScope.launch {
            repository.toggleNoteSaved(note.id, note.isSaved)
        }
    }

    // Admin Operations
    fun toggleUserRole() {
        viewModelScope.launch {
            val current = currentUser.value?.role ?: "STUDENT"
            val nextRole = if (current == "STUDENT") "ADMIN" else "STUDENT"
            repository.switchRole(nextRole)
            triggerMockNotification("Switched mode to $nextRole")
        }
    }

    fun addNewBook(
        title: String,
        subject: String,
        form: String,
        author: String,
        publisher: String,
        year: Int,
        pages: Int,
        fileSize: String,
        description: String,
        content: String
    ) {
        viewModelScope.launch {
            val newBook = BookEntity(
                id = "book_" + System.currentTimeMillis(),
                title = title,
                subject = subject,
                formLevel = form,
                author = author,
                publisher = publisher,
                year = year,
                pages = pages,
                fileSize = fileSize,
                description = description,
                pdfContent = content,
                isPublished = true
            )
            repository.insertBook(newBook)
            triggerMockNotification("New Book Published: $title")
        }
    }

    fun deleteBook(bookId: String) {
        viewModelScope.launch {
            repository.deleteBookById(bookId)
            triggerMockNotification("Book removed from library.")
        }
    }

    fun toggleBookPublished(bookId: String, current: Boolean) {
        viewModelScope.launch {
            repository.setBookPublished(bookId, !current)
        }
    }
}
