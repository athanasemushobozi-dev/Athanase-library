package com.example.ui.screens.quiz

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.QuizEntity
import com.example.data.local.QuizQuestionEntity
import com.example.data.model.AppLanguage
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CoralTanzania
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun QuizScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val activeQuiz by viewModel.activeQuiz.collectAsState()
    val isCompleted by viewModel.isQuizCompleted.collectAsState()
    val lastResult by viewModel.lastQuizResult.collectAsState()
    val questions by viewModel.quizQuestions.collectAsState()
    val currentIndex by viewModel.currentQuestionIndex.collectAsState()
    val selectedAnswers by viewModel.userSelectedAnswers.collectAsState()
    val secondsElapsed by viewModel.quizSecondsElapsed.collectAsState()
    val quizzes by viewModel.allQuizzes.collectAsState()
    val dailyQuiz by viewModel.dailyQuiz.collectAsState()
    val resultsHistory by viewModel.quizResults.collectAsState()
    val language by viewModel.language.collectAsState()
    val isSwahili = language == AppLanguage.KISWAHILI

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("quiz_screen")
    ) {
        if (activeQuiz == null) {
            // Quiz List / Dashboard
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                item {
                    Column {
                        Text(
                            text = if (isSwahili) "Majaribio na Mitihani ya Mazoezi" else "Interactive Quizzes & Practice",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = if (isSwahili) "Pima uelewa wako kulingana na mtaala wa NECTA."
                            else "Sharpen your exam readiness according to the NECTA syllabus.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Daily Challenge Card
                if (dailyQuiz != null) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.startQuiz(dailyQuiz!!) }
                                .testTag("quiz_daily_card"),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = NavyPrimary)
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Surface(
                                    color = AmberGold,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = if (isSwahili) "CHANGAMOTO YA LEO" else "TODAY'S CHALLENGE",
                                        color = Color(0xFF1A202C),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = dailyQuiz!!.title,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${dailyQuiz!!.subject} • ${dailyQuiz!!.formLevel} • ${dailyQuiz!!.questionCount} Questions",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Button(
                                    onClick = { viewModel.startQuiz(dailyQuiz!!) },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (isSwahili) "Anza Jaribio" else "Take Quiz Now")
                                }
                            }
                        }
                    }
                }

                // Quiz History / Performance Preview
                if (resultsHistory.isNotEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        tint = AmberGold,
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = if (isSwahili) "Majaribio Yaliyokamilika" else "Quizzes Completed",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "${resultsHistory.size} ${if (isSwahili) "Majaribio" else "Quizzes"} • Best: ${resultsHistory.maxOfOrNull { it.percentage } ?: 0}%",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // All Available Quizzes List
                item {
                    Text(
                        text = if (isSwahili) "Majaribio Yote ya Masomo" else "Subject Quizzes",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(quizzes) { quiz ->
                    ElevatedCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.startQuiz(quiz) }
                            .testTag("quiz_item_${quiz.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(NavyPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Quiz,
                                    contentDescription = null,
                                    tint = EmeraldAccent,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "${quiz.formLevel} • ${quiz.subject}",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Surface(
                                        color = when (quiz.difficulty.lowercase()) {
                                            "easy" -> EmeraldAccent.copy(alpha = 0.15f)
                                            "hard" -> CoralTanzania.copy(alpha = 0.15f)
                                            else -> AmberGold.copy(alpha = 0.15f)
                                        },
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = quiz.difficulty,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (quiz.difficulty.lowercase()) {
                                                "easy" -> EmeraldAccent
                                                "hard" -> CoralTanzania
                                                else -> AmberGold
                                            },
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = quiz.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )

                                Text(
                                    text = "${quiz.topic} • ${quiz.questionCount} ${if (isSwahili) "maswali" else "questions"}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        } else if (isCompleted && lastResult != null) {
            // Quiz Results & Review Screen
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("quiz_results_screen"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = NavyPrimary)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(90.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldAccent.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.EmojiEvents,
                                    contentDescription = null,
                                    tint = AmberGold,
                                    modifier = Modifier.size(50.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = if (lastResult!!.percentage >= 60) (if (isSwahili) "Hongera Sana!" else "Great Job!")
                                else (if (isSwahili) "Jitihada Zaidi!" else "Keep Practicing!"),
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                text = lastResult!!.quizTitle,
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 13.sp
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "${lastResult!!.percentage}%",
                                color = AmberGold,
                                fontSize = 42.sp,
                                fontWeight = FontWeight.ExtraBold
                            )

                            Text(
                                text = "${lastResult!!.score} / ${lastResult!!.totalQuestions} ${if (isSwahili) "Majibu Sahihi" else "Correct Answers"}",
                                color = Color.White,
                                fontSize = 14.sp
                            )

                            Text(
                                text = "${if (isSwahili) "Muda uliotumika" else "Time taken"}: ${lastResult!!.timeTakenSeconds}s",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.startQuiz(activeQuiz!!) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent)
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isSwahili) "Jaribu Tena" else "Try Again")
                        }

                        OutlinedButton(
                            onClick = { viewModel.startQuiz(quizzes.first()) }, // reset
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (isSwahili) "Rudi Orodhani" else "All Quizzes")
                        }
                    }
                }

                item {
                    Text(
                        text = if (isSwahili) "Pitia Majibu na Ufafanuzi" else "Review Answers & Detailed Explanations",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                itemsIndexed(questions) { index, q ->
                    val userAns = selectedAnswers[index]
                    val isCorrect = userAns == q.correctAnswerIndex

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Q${index + 1}: ${q.questionText}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(
                                    imageVector = if (isCorrect) Icons.Default.CheckCircle else Icons.Default.Cancel,
                                    contentDescription = null,
                                    tint = if (isCorrect) EmeraldAccent else CoralTanzania,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            val options = listOf(q.optionA, q.optionB, q.optionC, q.optionD)
                            val correctLetter = when (q.correctAnswerIndex) {
                                0 -> "A"; 1 -> "B"; 2 -> "C"; else -> "D"
                            }
                            val userLetter = when (userAns) {
                                0 -> "A"; 1 -> "B"; 2 -> "C"; 3 -> "D"; else -> "None"
                            }

                            Text(
                                text = "${if (isSwahili) "Jibu lako" else "Your answer"}: ($userLetter) ${options.getOrElse(userAns ?: -1) { "Not answered" }}",
                                fontSize = 12.sp,
                                color = if (isCorrect) EmeraldAccent else CoralTanzania,
                                fontWeight = FontWeight.SemiBold
                            )

                            if (!isCorrect) {
                                Text(
                                    text = "${if (isSwahili) "Jibu sahihi" else "Correct answer"}: ($correctLetter) ${options[q.correctAnswerIndex]}",
                                    fontSize = 12.sp,
                                    color = EmeraldAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = if (isSwahili) "Ufafanuzi (Explanation):" else "Explanation:",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = q.explanation,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Active Question Session
            val currentQ = questions.getOrNull(currentIndex)
            if (currentQ != null) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .testTag("active_quiz_session"),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        // Top bar inside quiz
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${activeQuiz!!.subject} • ${activeQuiz!!.formLevel}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldAccent
                            )

                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Timer,
                                        contentDescription = null,
                                        tint = NavyPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${secondsElapsed}s",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = NavyPrimary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Progress bar
                        LinearProgressIndicator(
                            progress = { (currentIndex + 1).toFloat() / questions.size.coerceAtLeast(1) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = EmeraldAccent
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (isSwahili) "Swali la ${currentIndex + 1} kati ya ${questions.size}"
                            else "Question ${currentIndex + 1} of ${questions.size}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Question Card
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text(
                                    text = currentQ.questionText,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    lineHeight = 24.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Options
                        val options = listOf(
                            "A" to currentQ.optionA,
                            "B" to currentQ.optionB,
                            "C" to currentQ.optionC,
                            "D" to currentQ.optionD
                        )

                        options.forEachIndexed { optIdx, (letter, text) ->
                            val isSelected = selectedAnswers[currentIndex] == optIdx

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) EmeraldAccent else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable { viewModel.selectAnswer(optIdx) }
                                    .testTag("quiz_option_$letter"),
                                color = if (isSelected) EmeraldAccent.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(if (isSelected) EmeraldAccent else MaterialTheme.colorScheme.surfaceVariant),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = letter,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 13.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = text,
                                        fontSize = 14.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }

                    // Navigation Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.prevQuestion() },
                            enabled = currentIndex > 0,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (isSwahili) "Iliyopita" else "Previous")
                        }

                        Button(
                            onClick = { viewModel.nextQuestion() },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("quiz_next_btn")
                        ) {
                            Text(
                                text = if (currentIndex == questions.size - 1) (if (isSwahili) "Wasilisha" else "Submit Quiz")
                                else (if (isSwahili) "Inayofuata" else "Next Question")
                            )
                        }
                    }
                }
            }
        }
    }
}
