package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Colors: Deep Academic Navy & Vibrant Emerald
val NavyPrimary = Color(0xFF0F3057)
val NavyDark = Color(0xFF071E3D)
val NavyLight = Color(0xFF28527A)

val EmeraldAccent = Color(0xFF00A86B)
val EmeraldDark = Color(0xFF00754A)
val EmeraldLight = Color(0xFF5CE1A6)

val AmberGold = Color(0xFFF7B731)
val CoralTanzania = Color(0xFFEB5757)

// Light Theme Palette
val LightBackground = Color(0xFFF6F8FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE9ECEF)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF1B2430)
val LightOnSurfaceVariant = Color(0xFF596E79)
val LightOutline = Color(0xFFD0D7DE)

// Dark Theme Palette
val DarkBackground = Color(0xFF0A1118)
val DarkSurface = Color(0xFF131F2D)
val DarkSurfaceVariant = Color(0xFF1E2D3F)
val DarkOnPrimary = Color(0xFF0A1118)
val DarkOnSurface = Color(0xFFE8EDF2)
val DarkOnSurfaceVariant = Color(0xFFA0B3C6)
val DarkOutline = Color(0xFF2A3C50)

// Category / Subject Colors
val MathColor = Color(0xFF3B82F6)
val PhysicsColor = Color(0xFF8B5CF6)
val ChemistryColor = Color(0xFFEC4899)
val BiologyColor = Color(0xFF10B981)
val EnglishColor = Color(0xFFF59E0B)
val KiswahiliColor = Color(0xFF14B8A6)
val GeographyColor = Color(0xFF6366F1)
val HistoryColor = Color(0xFFEF4444)
val CivicsColor = Color(0xFF84CC16)
val IctColor = Color(0xFF06B6D4)
