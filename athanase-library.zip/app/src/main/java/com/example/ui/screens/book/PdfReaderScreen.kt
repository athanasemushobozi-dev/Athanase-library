package com.example.ui.screens.book

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BookEntity
import com.example.data.model.AppLanguage
import com.example.ui.theme.AmberGold
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfReaderScreen(
    book: BookEntity,
    viewModel: MainViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentPage by viewModel.readerCurrentPage.collectAsState()
    val isNightMode by viewModel.readerNightMode.collectAsState()
    val fontSize by viewModel.readerFontSize.collectAsState()
    val bookmarkedPages by viewModel.bookmarkedPages.collectAsState()
    val language by viewModel.language.collectAsState()
    val isSwahili = language == AppLanguage.KISWAHILI

    val isBookmarked = bookmarkedPages.contains(currentPage)

    // Dynamic reader background and text colors
    val readerBackground = if (isNightMode) Color(0xFF121820) else Color(0xFFFCFDFD)
    val readerTextColor = if (isNightMode) Color(0xFFE2E8F0) else Color(0xFF1E293B)
    val cardBackground = if (isNightMode) Color(0xFF1E293B) else Color(0xFFF1F5F9)

    // Split book content into virtual pages for realistic reading pagination
    val pagesList = book.pdfContent.split("Page ").filter { it.isNotBlank() }
    val displayContent = if (pagesList.isNotEmpty()) {
        val pageIdx = (currentPage - 1).coerceIn(0, pagesList.size - 1)
        "Page " + pagesList[pageIdx]
    } else {
        book.pdfContent.ifBlank {
            """
            CHAPTER 1: INTRODUCTION
            
            Welcome to ${book.title}.
            This section covers foundational concepts and syllabus expectations for ${book.formLevel} in Tanzania.
            
            1. Core Learning Competencies:
            Students are expected to master key principles, perform accurate quantitative analysis, and prepare for NECTA examination standards.
            
            2. Study Tips:
            - Summarize key formulas at the end of each study session.
            - Practice with past examination questions in the Past Papers section.
            - Ask the AI Tutor if any step or derivation is unclear.
            """.trimIndent()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = book.title,
                            maxLines = 1,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${book.subject} • ${book.formLevel}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("reader_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    // Zoom Out
                    IconButton(
                        onClick = { viewModel.zoomOut() },
                        modifier = Modifier.testTag("reader_zoom_out")
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Zoom out")
                    }
                    // Zoom In
                    IconButton(
                        onClick = { viewModel.zoomIn() },
                        modifier = Modifier.testTag("reader_zoom_in")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Zoom in")
                    }
                    // Day / Night Toggle
                    IconButton(
                        onClick = { viewModel.toggleReaderNightMode() },
                        modifier = Modifier.testTag("reader_theme_toggle")
                    ) {
                        Icon(
                            imageVector = if (isNightMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle night mode"
                        )
                    }
                    // Bookmark Page
                    IconButton(
                        onClick = { viewModel.toggleBookmarkCurrentPage() },
                        modifier = Modifier.testTag("reader_bookmark_btn")
                    ) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Bookmark page",
                            tint = if (isBookmarked) AmberGold else MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = if (isNightMode) NavyDark else MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Surface(
                color = if (isNightMode) Color(0xFF182230) else MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    // Page indicator and jump
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isSwahili) "Ukurasa $currentPage kati ya ${book.pages}"
                            else "Page $currentPage of ${book.pages}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isNightMode) Color.White else NavyPrimary
                        )

                        if (isBookmarked) {
                            Surface(
                                color = AmberGold.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = if (isSwahili) "Umetia Alama" else "Bookmarked",
                                    color = AmberGold,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    // Progress Slider
                    Slider(
                        value = currentPage.toFloat(),
                        onValueChange = { viewModel.setReaderPage(it.toInt()) },
                        valueRange = 1f..book.pages.toFloat().coerceAtLeast(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = EmeraldAccent,
                            activeTrackColor = EmeraldAccent
                        ),
                        modifier = Modifier.testTag("reader_page_slider")
                    )

                    // Page Navigation Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.prevPage() },
                            enabled = currentPage > 1,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("reader_prev_page")
                        ) {
                            Icon(imageVector = Icons.Default.NavigateBefore, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isSwahili) "Iliyopita" else "Previous")
                        }

                        Button(
                            onClick = { viewModel.nextPage() },
                            enabled = currentPage < book.pages,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("reader_next_page")
                        ) {
                            Text(if (isSwahili) "Inayofuata" else "Next")
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(imageVector = Icons.Default.NavigateNext, contentDescription = null)
                        }
                    }
                }
            }
        },
        modifier = modifier
            .fillMaxSize()
            .testTag("pdf_reader_screen")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(readerBackground)
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header inside the page
                Surface(
                    color = cardBackground,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${book.subject} • NECTA Syllabus",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldAccent
                        )
                        Text(
                            text = "Form ${book.formLevel.filter { it.isDigit() }}",
                            fontSize = 11.sp,
                            color = readerTextColor.copy(alpha = 0.7f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Structured Chapter Text
                Text(
                    text = displayContent,
                    fontSize = fontSize.sp,
                    lineHeight = (fontSize * 1.6).sp,
                    color = readerTextColor,
                    fontFamily = FontFamily.Serif,
                    modifier = Modifier.testTag("reader_content_text")
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Offline Notice Pill
                Surface(
                    color = cardBackground,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.OfflinePin,
                            contentDescription = null,
                            tint = EmeraldAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isSwahili) "Kitabu hiki kimehifadhiwa kwenye kumbukumbu ya simu kwa matumizi bila intaneti."
                            else "This material is available offline. Reading progress is saved automatically.",
                            fontSize = 12.sp,
                            color = readerTextColor.copy(alpha = 0.8f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}
