package com.example.ui.screens.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.FormLevel
import com.example.data.model.Subject
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CoralTanzania
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val books by viewModel.allAdminBooks.collectAsState()
    val quizzes by viewModel.allAdminQuizzes.collectAsState()
    val language by viewModel.language.collectAsState()
    val isSwahili = language == AppLanguage.KISWAHILI

    var showAddBookDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (isSwahili) "Dashibodi ya Usimamizi" else "Admin Dashboard",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "ATHANASE LIBRARY Management",
                            fontSize = 11.sp,
                            color = CoralTanzania
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("admin_back_btn")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Student View")
                    }
                },
                actions = {
                    FilledTonalButton(
                        onClick = { showAddBookDialog = true },
                        modifier = Modifier.padding(end = 8.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isSwahili) "Ongeza Kitabu" else "Add Book", fontSize = 12.sp)
                    }
                }
            )
        },
        modifier = modifier
            .fillMaxSize()
            .testTag("admin_dashboard_screen")
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Analytics Overview Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AdminMetricCard(
                        title = if (isSwahili) "Jumla ya Vitabu" else "Total Books",
                        value = "${books.size}",
                        icon = Icons.Default.MenuBook,
                        color = NavyPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    AdminMetricCard(
                        title = if (isSwahili) "Wanafunzi Hai" else "Active Students",
                        value = "1,420",
                        icon = Icons.Default.People,
                        color = EmeraldAccent,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AdminMetricCard(
                        title = if (isSwahili) "Vipakuliwa" else "Total Downloads",
                        value = "3,890",
                        icon = Icons.Default.Download,
                        color = AmberGold,
                        modifier = Modifier.weight(1f)
                    )
                    AdminMetricCard(
                        title = if (isSwahili) "Majaribio" else "Total Quizzes",
                        value = "${quizzes.size}",
                        icon = Icons.Default.Quiz,
                        color = CoralTanzania,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Management Section Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isSwahili) "Usimamizi wa Vitabu" else "Book Catalog Management",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${books.size} ${if (isSwahili) "vitabu vilivyosajiliwa" else "registered books"}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Books List with Management Actions
            items(books, key = { it.id }) { book ->
                ElevatedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_book_item_${book.id}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    color = if (book.isPublished) EmeraldAccent.copy(alpha = 0.15f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (book.isPublished) "PUBLISHED" else "DRAFT",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (book.isPublished) EmeraldAccent else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text(
                                    text = "${book.formLevel} • ${book.subject}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = book.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "${book.author} • ${book.pages} pgs • ${book.fileSize}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Actions: Publish toggle and Delete
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { viewModel.toggleBookPublished(book.id, book.isPublished) }
                            ) {
                                Icon(
                                    imageVector = if (book.isPublished) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Toggle publish",
                                    tint = if (book.isPublished) EmeraldAccent else MaterialTheme.colorScheme.outline
                                )
                            }
                            IconButton(
                                onClick = { viewModel.deleteBook(book.id) }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete book",
                                    tint = CoralTanzania
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog: Add New Book
    if (showAddBookDialog) {
        AddBookDialog(
            onDismiss = { showAddBookDialog = false },
            onAddBook = { title, subject, form, author, publisher, year, pages, size, desc, content ->
                viewModel.addNewBook(title, subject, form, author, publisher, year, pages, size, desc, content)
                showAddBookDialog = false
            }
        )
    }
}

@Composable
fun AdminMetricCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
                Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = color)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun AddBookDialog(
    onDismiss: () -> Unit,
    onAddBook: (String, String, String, String, String, Int, Int, String, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedSubject by remember { mutableStateOf(Subject.MATHEMATICS) }
    var selectedForm by remember { mutableStateOf(FormLevel.FORM_4) }
    var author by remember { mutableStateOf("") }
    var publisher by remember { mutableStateOf("Tanzania Institute of Education") }
    var year by remember { mutableStateOf("2024") }
    var pages by remember { mutableStateOf("180") }
    var fileSize by remember { mutableStateOf("4.5 MB") }
    var description by remember { mutableStateOf("") }
    var chapterContent by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = "Add New Educational Book", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Book Title (e.g., Chemistry Form 4)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = author,
                    onValueChange = { author = it },
                    label = { Text("Author(s)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pages,
                        onValueChange = { pages = it },
                        label = { Text("Pages") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = fileSize,
                        onValueChange = { fileSize = it },
                        label = { Text("Size") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Curriculum Description / Summary") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )

                OutlinedTextField(
                    value = chapterContent,
                    onValueChange = { chapterContent = it },
                    label = { Text("Chapter 1 Sample Content / Study Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onAddBook(
                            title,
                            selectedSubject.displayNameEn,
                            selectedForm.displayNameEn,
                            author.ifBlank { "Educational Board of Tanzania" },
                            publisher,
                            year.toIntOrNull() ?: 2024,
                            pages.toIntOrNull() ?: 180,
                            fileSize,
                            description.ifBlank { "Standard syllabus textbook for secondary school education in Tanzania." },
                            chapterContent.ifBlank { "Chapter 1: Core Principles and Foundations. Study key terms and exam formulations." }
                        )
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("Publish to Library")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
